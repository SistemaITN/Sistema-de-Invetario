package Controlador;

import Modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CtrlInventario extends Conexion{

    String nombre = "";
    
    //Funcion
    public String obtenerNombre(int id){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        
        String sql = "select nombre from producto where id = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ""+id);
            rs = ps.executeQuery();
            while(rs.next()){
                nombre = rs.getString(1);
            }
            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: \n"+e);
        }
        return nombre;
    }
    
    public int codinv(){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        try {
            String sql = "select right(cod_venta,3) from venta where cod_venta like 'A%' order by id desc limit 1";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }else{
                return 1;
            }
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        }
    }
    
    public ArrayList<String> laboratorios(){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        ArrayList list = new ArrayList();
        String lab = null;
        try {
            String sql = "select laboratorio from proveedor";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                lab = rs.getString(1);
                list.add(lab);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }
    
    public int id(String lab){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        int id = 0;
        try {
            String sql = "select id from proveedor where laboratorio = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, lab);
            rs = ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }
            rs.close();
            return id;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return id;
        }
    }
    
    public int idVenta(){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        int id =0;
        String sql = "select max(id) from venta where cod_venta like 'A%'";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }
            rs.close();
            return id;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return id;
        }
    }
    
    public int idProducto(String nombre){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        int id = 0;
        String sql = "select id from producto where nombre = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            rs = ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }
            return id;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return id;
        }
    }
    
    public int idProveedor(String cod){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        int id = 0;
        String sql = "select id_proveedor from venta where cod_venta = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, cod);
            rs = ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }
            return id;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return id;
        }
    }
    
    public int idVenta(String cod){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        int id = 0;
        String sql = "select id from venta where cod_venta = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, cod);
            rs = ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }
            return id;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return id;
        }
    }
    
    public ArrayList<String> idsVenta(int id){
        Connection con = getConexion();
        PreparedStatement ps;
        ResultSet rs;
        ArrayList<String> ids = new ArrayList<>();
        String sql = "select id_venta from operacion where id_producto = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while(rs.next()){
                String idv = rs.getString(1);
                if(idv != null){
                    ids.add(idv);
                }
            }
            System.out.println(ids);
            ps.close();
            rs.close();
            return ids;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlInventario.class.getName()).log(Level.SEVERE, null, ex);
            return ids;
        }
    }
    
}
