package Controlador;

import Modelo.ConsProducto;
import Modelo.Producto;
import Utilidades.ModeloDeTabla;
import Utilidades.ProveedorDeDatosPaginacion;
import Vista.frmProductoB;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.event.TableModelEvent;
import javax.swing.event.TableModelListener;


public class CtrlProducto implements ActionListener,TableModelListener{
    
    private final frmProductoB view;
    private final ConsProducto model;
    private PaginadorDeTabla<Producto> paginadorDeTabla;
    
    public final void events(){
        view.cbxFilasPermitidas.addActionListener(this);
        view.tblProducto.getModel().addTableModelListener(this);
    }
    
    public CtrlProducto(frmProductoB view){
        this.view = view;
        model = new ConsProducto();
        
        ProveedorDeDatosPaginacion<Producto> proveedorDeDatosPaginacion = crearProveedorDeDatos();
        
        paginadorDeTabla = new PaginadorDeTabla(view.tblProducto,proveedorDeDatosPaginacion,new int[]{5,10,20,50,75,100},10);
        paginadorDeTabla.crearListadoDeFilasPermitidas(view.paginacionPanel);
        //System.out.println(proveedorDeDatosPaginacion.getTotalRowCount());//Mostrar numero de Registros
        
        view.cbxFilasPermitidas = paginadorDeTabla.getCbxFilasPermitidas();
        
        events();
        
        view.cbxFilasPermitidas.setSelectedItem(Integer.parseInt("10"));
    }

    private ProveedorDeDatosPaginacion<Producto> crearProveedorDeDatos(){
        
        List<Producto> lista = model.Buscar();
        
        return new ProveedorDeDatosPaginacion<Producto>() {
            @Override
            public int getTotalRowCount() {
                return lista.size();//Tamaño de la busqueda
            }

            @Override
            public List<Producto> getRow(int startIndex, int endIndex) {
                return lista.subList(startIndex, endIndex);//Devolver el numero de registros a mostrar
            }
        };
    };

    @Override
    public void actionPerformed(ActionEvent ae) {
        Object evt = ae.getSource();
        
        if(evt.equals(view.cbxFilasPermitidas)){
            paginadorDeTabla.eventComboBox(view.cbxFilasPermitidas);
        }
    }

    @Override
    public void tableChanged(TableModelEvent tme) {
        paginadorDeTabla.actualizarBotonesPaginacion();
    }
}
