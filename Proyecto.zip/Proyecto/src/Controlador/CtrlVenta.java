package Controlador;

import Modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CtrlVenta extends Conexion{
    
    public int buscar(String cod){
        int id = 0;
        try {
            Connection con = getConexion();
            PreparedStatement ps;
            ResultSet rs;
            String sql = "select id from venta where cod_venta = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, cod);
            rs = ps.executeQuery();
            if(rs.next()){
                id = rs.getInt(1);
            }
            return id;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlVenta.class.getName()).log(Level.SEVERE, null, ex);
            return id;
        }
    }
    
    
    
}
