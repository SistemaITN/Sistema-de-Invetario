package Controlador;

import Modelo.Conexion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class CtrlOperacion extends Conexion{
    
    PreparedStatement ps;
    ResultSet rs;
    Connection con = getConexion();
    
    public int ObtenerId(){
        int id = 0;
        String sql = "select max(id) from Producto";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                id = rs.getInt(1);
            }
            rs.close();
        } catch (Exception e) {
        }finally{
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(CtrlOperacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return id;
    }
    
    public int ObtenerIdVenta(){
        int id = 0;
        String sql = "select max(id) from Venta where id_proveedor is null";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                id = rs.getInt(1);
            }
            rs.close();
        } catch (Exception e) {
        }finally{
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(CtrlOperacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return id;
    }
    
    public int ObtenerCodigo(){
        String id = null;
        int codigo = 0;
        String sql = "select max(substring(cod_venta,2,4))+1 from Venta where cod_venta like 'F%'";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                id = rs.getString(1);
            }
            if(id!=null){
                codigo = Integer.parseInt(id);
            }else{
                codigo = 1;
            }
            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo obtener codigo de factura\nError: "+e.toString());
        }finally{
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(CtrlOperacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return codigo;
    }
    
        public int ObtenerCodigoA(){
        String id = null;
        int codigo = 0;
        String sql = "select count(id) from Venta where id_proveedor is not null";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                id = rs.getString(1);
            }
            if(id!=null){
                codigo = Integer.parseInt(id)+1;
            }else{
                codigo = 1;
            }
            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo obtener codigo de factura\nError: "+e.toString());
        }finally{
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(CtrlOperacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return codigo;
    }
    
    public int stockdisponible(int id){
        int stock = 0;
        String sql = "select sum(if(id_tipooperacion=1,q,0))-sum(if(id_tipooperacion=2,q,0)) as disponible from operacion where id_producto = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while(rs.next()){
                if(rs.getString("disponible") != null){
                    stock = Integer.parseInt(rs.getString("disponible"));
                }else if(rs.getString("disponible") == null){
                    stock = 0;
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error: "+e);
        }finally{
            try {
                rs.close();
            } catch (SQLException ex) {
                Logger.getLogger(CtrlOperacion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return stock;
    }
    
    public int vendido(int id,int idV){
        int can = 0;
        try {
            String sql = "select q from operacion where id_producto=? and id_venta=?";
            ps=con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.setInt(2, idV);
            rs = ps.executeQuery();
            if(rs.next()){
                can = rs.getInt(1);
            }
            return can;
        } catch (SQLException ex) {
            Logger.getLogger(CtrlOperacion.class.getName()).log(Level.SEVERE, null, ex);
            return can;
        }
    }
    
}
