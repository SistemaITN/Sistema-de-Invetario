package Controlador;

import Utilidades.ModeloDeTabla;
import Utilidades.ProveedorDeDatosPaginacion;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.Box;
import static javax.swing.GroupLayout.Alignment.CENTER;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JToggleButton;
import javax.swing.SwingConstants;

public class PaginadorDeTabla<T> {
    
    private JTable tabla;
    private ProveedorDeDatosPaginacion<T> proveedorDeDatosPaginacion;
    private int [] arrayFilasPermitidas;
    private int filasPermitidas;
    private ModeloDeTabla<T> modeloDeTabla;
    private int paginaActual = 1;
    
    private JComboBox<Integer> cbxFilasPermitidas;//Numero de registros a mostrar
    private JPanel panelpaginacionBotones;//Numero de Paginas
    private  final int limiteBotonesPaginadores = 9;
    
    //Contructor
    //Definir el numero de registros a mostrar en la tabla
    public PaginadorDeTabla(JTable tabla, ProveedorDeDatosPaginacion<T> proveedorDeDatosPaginacion, int[] arrayFilasPermitidas, int filasPermitidas) {
        this.tabla = tabla;
        this.proveedorDeDatosPaginacion = proveedorDeDatosPaginacion;
        this.arrayFilasPermitidas = arrayFilasPermitidas;
        this.filasPermitidas = filasPermitidas;
        init();
    }
    
    private void init(){
        inicializarModeloDeTabla();
        paginar();
    }
    
    private void inicializarModeloDeTabla(){
        try {
            this.modeloDeTabla = (ModeloDeTabla<T>) this.tabla.getModel();
        } catch (Exception e) {
            System.out.println("Error Metodo inicializarModeloDeTabla() "+e.getMessage());
        }
    }
    
    public void crearListadoDeFilasPermitidas(JPanel panelPaginador){
        
        panelpaginacionBotones = new JPanel(new GridLayout(1,limiteBotonesPaginadores,3,3));
        panelPaginador.add(panelpaginacionBotones);
        
        if(arrayFilasPermitidas!=null){
            
            Integer array[] = new Integer[arrayFilasPermitidas.length];
            for (int i = 0; i < arrayFilasPermitidas.length; i++) {
                array[i] = arrayFilasPermitidas[i];
            }
            cbxFilasPermitidas = new JComboBox<>(array);
            
            panelPaginador.add(Box.createHorizontalStrut(15));
            panelPaginador.add(new JLabel("Numero de Filas"));
            panelPaginador.add(cbxFilasPermitidas);
            
        }
        
    }
    
    public void eventComboBox(JComboBox<Integer> pageComboBox){
        int filaInicialPagina = ((paginaActual - 1) * filasPermitidas) + 1;
        filasPermitidas = (Integer) pageComboBox.getSelectedItem();
        paginaActual = ((filaInicialPagina - 1) / filasPermitidas) + 1;
        paginar();
    }
    
    public void actualizarBotonesPaginacion(){
        
        panelpaginacionBotones.removeAll();
        
        int totalFilas = proveedorDeDatosPaginacion.getTotalRowCount();
        
        int paginas = (int) Math.ceil((double)totalFilas / filasPermitidas);
        
        if(paginas>limiteBotonesPaginadores){
            
            agregarBotonesPaginacion(panelpaginacionBotones, 1);
            
            if(paginaActual<=(limiteBotonesPaginadores+1)/2){
                agregarRangoBotonesPaginacion(panelpaginacionBotones, 2, limiteBotonesPaginadores-2);
                panelpaginacionBotones.add(crearElipses());
                agregarBotonesPaginacion(panelpaginacionBotones, paginas);
            }else if(paginaActual>(paginas-((limiteBotonesPaginadores+1)/2))){
                panelpaginacionBotones.add(crearElipses());
                agregarRangoBotonesPaginacion(panelpaginacionBotones, paginas - limiteBotonesPaginadores + 3, paginas);
            }else{
                
                panelpaginacionBotones.add(crearElipses());
                int inicio = paginaActual - (limiteBotonesPaginadores - 4) / 2;
                int finalizacion = inicio + limiteBotonesPaginadores - 5;
                
                agregarRangoBotonesPaginacion(panelpaginacionBotones, inicio, finalizacion);
                panelpaginacionBotones.add(crearElipses());
                agregarBotonesPaginacion(panelpaginacionBotones, paginas);
                
            }
            
        }else{
            agregarRangoBotonesPaginacion(panelpaginacionBotones, 1, paginas);
        }
        
        panelpaginacionBotones.getParent().validate();
        panelpaginacionBotones.getParent().repaint() ;
        
    }
    
    private JLabel crearElipses(){
        return new JLabel("...",SwingConstants.CENTER);
    }
    
    private void agregarRangoBotonesPaginacion(JPanel panelPadre,int inicio,int finalizacion){
        
        int init = inicio;
        for (inicio = init; inicio <= finalizacion; inicio++) {
            agregarBotonesPaginacion(panelPadre, inicio);
        }
        
    }
    
    private void agregarBotonesPaginacion(JPanel panelPadre,int numeroPagina){
        
        JToggleButton toogleButton = new JToggleButton(Integer.toString(numeroPagina));
        
        toogleButton.setMargin(new Insets(1,3,1,3));
        
        panelPadre.add(toogleButton);
        
        if(numeroPagina==paginaActual){
            toogleButton.setSelected(true);
        }
        
        toogleButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                paginaActual = Integer.parseInt(ae.getActionCommand());
                paginar();
            }
        });
    }
    
    private void paginar(){
        
        int inicio = (paginaActual - 1) * filasPermitidas; // 1-1=0*10=0
        int finalizacion = inicio + filasPermitidas; // 0+10=10
        if(finalizacion > proveedorDeDatosPaginacion.getTotalRowCount()){
            finalizacion = proveedorDeDatosPaginacion.getTotalRowCount();
        }
        
        List<T> lista = proveedorDeDatosPaginacion.getRow(inicio, finalizacion);
        modeloDeTabla.setLista(lista);
        modeloDeTabla.fireTableDataChanged();
        
    }

    
    //get y Set
    public JComboBox<Integer> getCbxFilasPermitidas() {
        return cbxFilasPermitidas;
    }

    public void setCbxFilasPermitidas(JComboBox<Integer> cbxFilasPermitidas) {
        this.cbxFilasPermitidas = cbxFilasPermitidas;
    }
    
    
    
}
