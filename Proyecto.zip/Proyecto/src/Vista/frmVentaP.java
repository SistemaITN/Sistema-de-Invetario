package Vista;

import Controlador.CtrlInventario;
import Controlador.CtrlVenta;
import Modelo.Conexion;
import Modelo.Usuario;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmVentaP extends javax.swing.JFrame {

    Usuario usu;
    public static frmVenta frmV;
    public static frmVentaM frmM;
    public static frmVentaV frm;
    public frmVentaP() {
        initComponents();
    }
    
    public frmVentaP(Usuario usu){
        initComponents();
        this.usu = usu;
        cargar();
        
    }

    String[] botones ={"Si","No"}; 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVenta = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txtCampo = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        btnVender = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btmVisualizar = new javax.swing.JButton();
        txtEliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Modulo de Venta");

        tblVenta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo de Venta", "Cantidad", "Total", "fecha", "Usuario"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblVenta);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Codigo de Factura");

        txtCampo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtCampo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCampoKeyPressed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Buscar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        btnVender.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnVender.setText("Vender");
        btnVender.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVenderActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btmVisualizar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btmVisualizar.setText("Visualizar");
        btmVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btmVisualizarActionPerformed(evt);
            }
        });

        txtEliminar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtEliminar.setText("Eliminar");
        txtEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, 122, Short.MAX_VALUE)
                            .addComponent(btmVisualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 266, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(91, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(182, 182, 182)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addComponent(btnVender, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnVender, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addGap(48, 48, 48)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(btmVisualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(137, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCampoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCampoKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            cargar();
        }
    }//GEN-LAST:event_txtCampoKeyPressed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        frmHome.frmV = null;
    }//GEN-LAST:event_formWindowClosing

    private void btnVenderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVenderActionPerformed
        try {
            if(frmV == null && (usu.getTipo() == 1 || usu.getTipo() == 2)){
                dispose();

                frmV = new frmVenta(usu);
                frmV.setVisible(true);
                frmV.setTitle("Registrar Venta");
                frmV.setLocationRelativeTo(null);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se puede ingresar");
        }
    }//GEN-LAST:event_btnVenderActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        try {
            if(usu.getTipo()==1 && frmM == null){
                int fila = tblVenta.getSelectedRow();
                String cod = tblVenta.getValueAt(fila, 0).toString();
                CtrlVenta ctrlV = new CtrlVenta();
                int id = ctrlV.buscar(cod);
                frmM = new frmVentaM(usu, id);
                frmM.setVisible(true);
                frmM.setTitle("Modificar Factura");
                frmM.setLocationRelativeTo(null);
            }else if(usu.getTipo()==2){
                JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para ingresar a esta funcion");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se a seleccionado ninguna factura","Mensaje del sistema",2);
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btmVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btmVisualizarActionPerformed
        try {
            if(frm == null && (usu.getTipo()==1 || usu.getTipo()==2)){
                int fila = tblVenta.getSelectedRow();
                String cod = tblVenta.getValueAt(fila, 0).toString();
                CtrlVenta ctrlV = new CtrlVenta();
                int id = ctrlV.buscar(cod);
                frm = new frmVentaV(usu, id);
                frm.setTitle("Visualizar Factura");
                frm.setLocationRelativeTo(null);
                frm.setVisible(true);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una factura");
        }
    }//GEN-LAST:event_btmVisualizarActionPerformed

    private void txtEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtEliminarActionPerformed
        try {
            if(usu.getTipo() == 1){
                CtrlInventario ctrli = new CtrlInventario();
                int fila = tblVenta.getSelectedRow();
                String cod = tblVenta.getValueAt(fila, 0).toString();
                int idV = ctrli.idVenta(cod);
                int i =JOptionPane.showOptionDialog(null, "Seguro desea eliminar la factura "+cod+"\n al eliminarlo no podra recuperar la informacion","Mensaje de Confirmacion", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, botones, botones[0]);

                if(i == 0){
                    try {
                        Conexion conn = new Conexion();
                        Connection con = conn.getConexion();
                        PreparedStatement ps;
                        ps = con.prepareStatement("delete from operacion where id_venta = ?");
                        ps.setInt(1, idV);
                        ps.execute();
                        ps.close();
                        ps = con.prepareStatement("delete from venta where id = ?");
                        ps.setInt(1, idV);
                        ps.execute();
                        ps.close();
                        JOptionPane.showMessageDialog(null, "Eliminado con exito");
                        cargar();
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
            }else if(usu.getTipo() == 2){
                JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para ingresar a esta funcion");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una opcion");
            System.out.println(e);
        }
    }//GEN-LAST:event_txtEliminarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        cargar();
    }//GEN-LAST:event_jButton1ActionPerformed

    //Funciones
    private void cargar(){
        try {
            String campo = txtCampo.getText();
            String where = "where v.cod_venta like 'F%'";
            
            if(!"".equals(campo)){
                where = "where v.cod_venta like '%"+campo+"%' and v.cod_venta like 'F%'";
            }
            
            DefaultTableModel modelo = new DefaultTableModel();
            tblVenta.setModel(modelo);
            
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            
            modelo.addColumn("Codigo Factura");
            modelo.addColumn("Cantidad");
            modelo.addColumn("Total");
            modelo.addColumn("Usuario");
            modelo.addColumn("Fecha");
            
            int column[] = {100,100,100,100,200};
            
            String sql = "select v.id,v.cod_venta,v.total-v.descuento,v.fecha,u.nombre from venta as v inner join usuario as u on u.id=v.id_usuario "+where+" limit 20";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            
            for(int i=0;i<5;i++){
                tblVenta.getColumnModel().getColumn(i).setPreferredWidth(column[i]);
            }
            
            while(rs.next()){
                ResultSet rs1;
                String sqlC = "select sum(q) from operacion where id_venta = ?";
                ps = con.prepareStatement(sqlC);
                ps.setInt(1, rs.getInt(1));
                rs1 = ps.executeQuery();
                if(rs1.next()){
                    Object[] lista = new Object[5];
                    lista[0] = rs.getString(2);//Cod
                    lista[1] = rs1.getInt(1);//Cantidad
                    lista[2] = rs.getInt(3);//Total
                    lista[3] = rs.getString(5);//Usuario
                    lista[4] = rs.getString(4);//
                    modelo.addRow(lista);
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(frmVentaP.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmVentaP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmVentaP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmVentaP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmVentaP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmVentaP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btmVisualizar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnVender;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblVenta;
    private javax.swing.JTextField txtCampo;
    private javax.swing.JButton txtEliminar;
    // End of variables declaration//GEN-END:variables
}
