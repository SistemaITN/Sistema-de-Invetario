package Vista;

import Controlador.CtrlOperacion;
import Modelo.Conexion;
import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmVentaM extends javax.swing.JFrame {

    Usuario usu;
    int idV;
    int selec = 0;
    double totalp = 0;
    public frmVentaM() {
        initComponents();
    }
    
    public frmVentaM(Usuario usu,int id) {
        initComponents();
        this.usu = usu;
        this.idV = id;
        cargar(idV);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCodVen = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVenta = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        txtEfectivo = new javax.swing.JTextField();
        txtDescuento = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtProducto = new javax.swing.JTextField();
        txtPrecio = new javax.swing.JTextField();
        txtDisponible = new javax.swing.JTextField();
        txtCantidad = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtTot = new javax.swing.JTextField();
        btnModificar = new javax.swing.JButton();
        btlCambiar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Modificar venta");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Codigo de Venta:");

        txtCodVen.setEditable(false);
        txtCodVen.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        tblVenta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblVenta);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Total a pagar");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Efectivo");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Descuento");

        txtTotal.setEditable(false);
        txtTotal.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        txtTotal.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtTotalKeyTyped(evt);
            }
        });

        txtEfectivo.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        txtEfectivo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEfectivoKeyTyped(evt);
            }
        });

        txtDescuento.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        txtDescuento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDescuentoKeyTyped(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Nombre del Producto");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Cantidad");

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Disponibilidad");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Precio");

        txtProducto.setEditable(false);
        txtProducto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        txtPrecio.setEditable(false);
        txtPrecio.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        txtDisponible.setEditable(false);
        txtDisponible.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        txtCantidad.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCantidadKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCantidadKeyTyped(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Total");

        txtTot.setEditable(false);
        txtTot.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnModificar.setText("Seleccionar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btlCambiar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btlCambiar.setText("Modificar");
        btlCambiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btlCambiarActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("<html><center>Guardar<p>Cambios<html>");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("Cancelar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(152, 152, 152)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                            .addGap(235, 235, 235)
                                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.TRAILING)
                                                .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)))
                                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(txtEfectivo, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtTotal, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(txtDescuento, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(337, 337, 337)
                                    .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtCodVen, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtProducto))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jLabel9)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtPrecio)
                                    .addGap(18, 18, 18)
                                    .addComponent(jLabel8)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtDisponible))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(8, 8, 8))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel7)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(jLabel10)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txtTot, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(btlCambiar, javax.swing.GroupLayout.DEFAULT_SIZE, 115, Short.MAX_VALUE))))))
                .addContainerGap(69, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(jLabel1)
                .addGap(45, 45, 45)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtCodVen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDisponible, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txtTot, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btlCambiar, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtEfectivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txtDescuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        frmVentaP.frmM=null;
    }//GEN-LAST:event_formWindowClosed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        try {
            if(usu.getTipo()==1){
                int fila = tblVenta.getSelectedRow();
                int id = Integer.parseInt(tblVenta.getValueAt(fila, 0).toString());
                int can = Integer.parseInt(tblVenta.getValueAt(fila, 2).toString());
                selec = fila;
                txtProducto.setText(tblVenta.getValueAt(fila, 1).toString());
                txtCantidad.setText(tblVenta.getValueAt(fila, 2).toString());
                precio(id,can);
                txtCantidad.requestFocus();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione un producto","Mensaje del Sistema",2);
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void txtCantidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadKeyReleased
        float precio = Float.parseFloat(txtPrecio.getText());
        int cantidad = Integer.parseInt(txtCantidad.getText());
        String total = ""+precio*cantidad;
        txtTot.setText(total);
    }//GEN-LAST:event_txtCantidadKeyReleased

    private void txtCantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtCantidadKeyTyped

    private void btlCambiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btlCambiarActionPerformed
        try {
            if(usu.getTipo()==1){
                String cantidad = txtCantidad.getText();
                if(!"".equals(cantidad)){
                    int can = Integer.parseInt(cantidad);
                    int dis = Integer.parseInt(txtDisponible.getText());
                    if(can>0 && can<=dis){
                        double total = Double.parseDouble(txtTot.getText());
                        System.out.println(can+"/"+total);
                        tblVenta.setValueAt(can, selec, 2);
                        tblVenta.setValueAt(total, selec, 3);
                        total();
                        limpiar();
                        selec = 0;
                    }else{
                        JOptionPane.showMessageDialog(null, "Valor invalido","mensaje del Sistema",2);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "El campo se encuentra vacio");
                    txtCantidad.requestFocus();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo realizar el cambio","Mensaje del Sistema",0);
        }
    }//GEN-LAST:event_btlCambiarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            if(usu.getTipo()==1){
                Double total = Double.parseDouble(txtTotal.getText());
                Double efec = Double.parseDouble(txtEfectivo.getText());
                if(total<=efec){
                    String dato = txtDescuento.getText();
                    if(!"".equals(dato)){
                        if(UpdateV(idV)==1){
                            int filas = tblVenta.getRowCount();
                            int val = 0;
                            for(int i=0;i<filas;i++){
                                int id = Integer.parseInt(tblVenta.getValueAt(i, 0).toString());
                                int cantidad = Integer.parseInt(tblVenta.getValueAt(i, 2).toString());
                                if(actualizar(id, cantidad)==0){
                                    System.out.println("Error al modificar");
                                    val++;
                                }
                            }
                            if(val == 0){
                                JOptionPane.showMessageDialog(null, "Actualizado Correctamente");
                                dispose();
                                frmVentaP.frmM=null;
                            }else{
                                JOptionPane.showMessageDialog(null, "Error al actualizar");
                                
                            }
                        }else{
                            JOptionPane.showMessageDialog(null, "Error al modificar");
                        }
                    }else{
                        JOptionPane.showMessageDialog(null, "Valor del descuento invalido, colocar valor igual o mayor a 0");
                        txtEfectivo.requestFocus();
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Valor del efectivo invalido");
                    txtEfectivo.requestFocus();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo realizar los cambios");
            System.out.println(e);
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtDescuentoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDescuentoKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtDescuentoKeyTyped

    private void txtEfectivoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEfectivoKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtEfectivoKeyTyped

    private void txtTotalKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTotalKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtTotalKeyTyped

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        frmVentaP.frmM=null;
        dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    private void cargar(int id){
        DefaultTableModel modelo = new DefaultTableModel();
        tblVenta.setModel(modelo);
        modelo.addColumn("id");
        modelo.addColumn("Producto");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Total");
        
        int[] columnas = {0,150,50,70};
        for(int i = 1; i < 4; i++){
            tblVenta.getColumnModel().getColumn(i).setPreferredWidth(columnas[i]);
        }
        tblVenta.getColumnModel().getColumn(0).setMaxWidth(0);
        tblVenta.getColumnModel().getColumn(0).setMinWidth(0);
        tblVenta.getTableHeader().getColumnModel().getColumn(0).setMaxWidth(0);
        tblVenta.getTableHeader().getColumnModel().getColumn(0).setMinWidth(0);
        
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            String sql = "select p.id,p.nombre,o.q,p.pre_salida*o.q from (producto as p inner join operacion as o on p.id=o.id_producto) where o.id_venta = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while(rs.next()){
                Object[] lista = new Object[4];
                lista[0] = rs.getInt(1);
                lista[1] = rs.getString(2);
                lista[2] = rs.getInt(3);
                lista[3] = rs.getInt(4);
                modelo.addRow(lista);
            }
            rs.close();
            ps.close();
            datos(id);
            total();
        } catch (SQLException ex) {
            Logger.getLogger(frmVentaM.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void datos(int id){
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            String sql = "select cod_venta,descuento,efectivo from venta where id = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if(rs.next()){
                txtCodVen.setText(rs.getString(1));
                txtEfectivo.setText(rs.getString(3));
                txtDescuento.setText(rs.getString(2));
            }
        } catch (SQLException ex) {
            Logger.getLogger(frmVentaM.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private void total(){
        totalp = 0;
        int filas = tblVenta.getRowCount();
        for(int i = 0;i < filas; i++){
            double valor = Double.parseDouble(tblVenta.getValueAt(i,3).toString());
            totalp = totalp + valor;
        }
        txtTotal.setText(""+totalp);
    }
    
    private void precio(int id, int can){
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            String sql = "select pre_salida from producto where id = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if(rs.next()){
                txtPrecio.setText(rs.getString(1));
                CtrlOperacion ctrlO = new CtrlOperacion();
                txtDisponible.setText(""+(ctrlO.stockdisponible(id)+ctrlO.vendido(id, idV)));
                txtTot.setText(""+rs.getInt(1)*can);
            }
        } catch (SQLException ex) {
            Logger.getLogger(frmVentaM.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    private int UpdateV(int id){
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            String sql = "update venta set total = ?,efectivo = ?,descuento = ? where id = ?";
            ps = con.prepareStatement(sql);
            ps.setDouble(1, Double.parseDouble(txtTotal.getText()));
            ps.setDouble(2, Double.parseDouble(txtEfectivo.getText()));
            ps.setDouble(3, Double.parseDouble(txtDescuento.getText()));
            ps.setInt(4, id);
            ps.execute();
            ps.close();
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(frmVentaM.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    
    private int actualizar(int id,int q){
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            String sql = "update operacion set q = ? where id_producto = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, q);
            ps.setInt(2, id);
            ps.execute();
            ps.close();
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(frmVentaM.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    
    void limpiar(){
        txtProducto.setText("");
        txtPrecio.setText("");
        txtDisponible.setText("");
        txtCantidad.setText("");
        txtTot.setText("");
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmVentaM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmVentaM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmVentaM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmVentaM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmVentaM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btlCambiar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblVenta;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtCodVen;
    private javax.swing.JTextField txtDescuento;
    private javax.swing.JTextField txtDisponible;
    private javax.swing.JTextField txtEfectivo;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtProducto;
    private javax.swing.JTextField txtTot;
    private javax.swing.JTextField txtTotal;
    // End of variables declaration//GEN-END:variables
}
