package Vista;

import Controlador.CtrlOperacion;
import Modelo.ConsOperacion;
import Modelo.ConsProducto;
import Modelo.ConsVenta;
import Modelo.Operacion;
import Modelo.Producto;
import Modelo.Usuario;
import Modelo.Venta;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author marcela
 */
public class frmVenta extends javax.swing.JFrame {

    //Variables
    Usuario usu;
    Producto pro = new Producto();
    CtrlOperacion ctrlO = new CtrlOperacion();
    DefaultTableModel modelo;
    double tPagar = 0;
    double totalV = 0;
    int descuento = 0;
    int efectivo = 0;
    
    public frmVenta() {
        initComponents();
        
    }
    
    public frmVenta(Usuario usu) {
        initComponents();
        this.usu = usu;
        txtBuscar.requestFocus();
        txtCodVenta.setText(codFactura());
        txtis.setVisible(false);
        this.setLocationRelativeTo(null);
        Estructura();
    }
    
    
    String codFactura(){
        String cod = null;
        int i = ctrlO.ObtenerCodigo();
        if(i<10){
            cod = "F00"+i;
        }else if(i<100){
            cod = "F0"+i;
        }else if(i<1000){
            cod = "F"+i;
        }
        return cod;
    }
    
    void vaciar(){
        registrarVenta();
        registrarOperacion();
        limpiar();
        CancelarVen();
        txtCodVenta.setText(codFactura());
        txtEfectivo.setText("");
        txtDescuento.setText("0");
        txtPagar.setText("0.0");
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        txtCodVenta = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtProducto = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtPrecio = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtStock = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txtTotal = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        txtis = new javax.swing.JTextField();
        btnAgregar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVenta = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        txtPagar = new javax.swing.JTextField();
        btnEliminar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtDescuento = new javax.swing.JTextField();
        txtEfectivo = new javax.swing.JTextField();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Registrar Venta");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 22)); // NOI18N
        jLabel1.setText("Codigo de Venta");

        txtCodVenta.setEditable(false);
        txtCodVenta.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N
        txtCodVenta.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Producto");

        txtBuscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtBuscarKeyPressed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Nombre del Producto:");

        txtProducto.setEditable(false);
        txtProducto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Precio");

        txtPrecio.setEditable(false);
        txtPrecio.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtPrecio.setText("0");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Disponible");

        txtStock.setEditable(false);
        txtStock.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Cantidad:");

        txtCantidad.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtCantidad.setText("0");
        txtCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCantidadKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtCantidadKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCantidadKeyTyped(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Total");

        txtTotal.setEditable(false);
        txtTotal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        txtis.setEditable(false);

        btnAgregar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnAgregar.setText("Agregar");
        btnAgregar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnAgregarMouseClicked(evt);
            }
        });

        jScrollPane1.setPreferredSize(new java.awt.Dimension(452, 300));

        tblVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Producto", "Cantidad", "Total", "Id"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Float.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblVenta);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Total a pagar");

        txtPagar.setEditable(false);
        txtPagar.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        txtPagar.setText("0.0");

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnEliminar.setText("Eliminar Fila");
        btnEliminar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnEliminarMouseClicked(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton1.setText("Cancelar Venta");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        jButton2.setText("Generar Venta");
        jButton2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton2MouseClicked(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel9.setText("Descuento");

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("Efectivo");

        txtDescuento.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        txtDescuento.setText("0");
        txtDescuento.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtDescuentoKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtDescuentoKeyTyped(evt);
            }
        });

        txtEfectivo.setFont(new java.awt.Font("Tahoma", 3, 14)); // NOI18N
        txtEfectivo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtEfectivoKeyPressed(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEfectivoKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(328, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel9)
                                .addGap(7, 7, 7))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtPagar, javax.swing.GroupLayout.DEFAULT_SIZE, 128, Short.MAX_VALUE)
                            .addComponent(txtEfectivo)
                            .addComponent(txtDescuento)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(16, 16, 16)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel1)
                                    .addGap(18, 18, 18)
                                    .addComponent(txtCodVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 251, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(btnBuscar))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtProducto))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, 167, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jLabel5)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel6)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel7)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(btnAgregar)))
                                .addComponent(txtis, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(109, 109, 109)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 138, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(141, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(59, 59, 59)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtCodVenta)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtis, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txtProducto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtPrecio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txtStock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(txtTotal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAgregar))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txtPagar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEfectivo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(txtDescuento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 19, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    private void txtCantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtCantidadKeyTyped

    private void txtBuscarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            buscar();
        }
    }//GEN-LAST:event_txtBuscarKeyPressed

    private void txtCantidadKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadKeyReleased
        float precio = Float.parseFloat(txtPrecio.getText());
        int cantidad = Integer.parseInt(txtCantidad.getText());
        String total = ""+precio*cantidad;
        txtTotal.setText(total);
    }//GEN-LAST:event_txtCantidadKeyReleased

    private void btnAgregarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnAgregarMouseClicked
        agregarTabla();
        calcularTotal();
    }//GEN-LAST:event_btnAgregarMouseClicked

    private void txtCantidadKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            agregarTabla();
            calcularTotal();
        }
    }//GEN-LAST:event_txtCantidadKeyPressed

    private void btnEliminarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEliminarMouseClicked
        eliminarFila();
        txtBuscar.requestFocus();
    }//GEN-LAST:event_btnEliminarMouseClicked

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        CancelarVen();
    }//GEN-LAST:event_jButton1MouseClicked

    private void jButton2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton2MouseClicked
        obtenerDatos();
        int efectivo = Integer.parseInt(txtEfectivo.getText());
        if(tPagar!=0 && efectivo>=tPagar){
            vaciar();
        }
    }//GEN-LAST:event_jButton2MouseClicked

    private void txtEfectivoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEfectivoKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtEfectivoKeyTyped

    private void txtDescuentoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDescuentoKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtDescuentoKeyTyped

    private void txtEfectivoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEfectivoKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            obtenerDatos();
            int efectivo = Integer.parseInt(txtEfectivo.getText());
            if(tPagar!=0 && efectivo>=tPagar){
                vaciar();
            }
        }
    }//GEN-LAST:event_txtEfectivoKeyPressed

    private void txtDescuentoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDescuentoKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            obtenerDatos();
            int efectivo = Integer.parseInt(txtEfectivo.getText());
            if(tPagar!=0 && efectivo>=tPagar){
                vaciar();
            }
        }
    }//GEN-LAST:event_txtDescuentoKeyPressed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        frmVentaP.frmV = null;
        frmVentaP frm = new frmVentaP(usu);
        frm.setVisible(true);
        frm.setTitle("Modulo Ventas");
        frm.setLocationRelativeTo(null);
    }//GEN-LAST:event_formWindowClosing

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        buscar();
    }//GEN-LAST:event_btnBuscarActionPerformed

    //Funciones
    
    void buscar(){
        try {
            if(usu.getTipo() == 1 || usu.getTipo() == 2){
                String campo = txtBuscar.getText();

                if(!"".equals(campo)){
                    ConsProducto conP = new ConsProducto();
                    pro = conP.identificar(campo);
                    //Si el campo esta vacia
                    String prueba = pro.getNombre();
                    int num = pro.getBarras();
                    if(prueba == null || num==0){
                        JOptionPane.showMessageDialog(null, "El producuto buscado no existe.\nIntentelo nuevamente");
                        txtBuscar.setText(null);
                        txtBuscar.requestFocus();
                    }else{
                        int id = pro.getId();
                        txtis.setText(""+id);
                        CtrlOperacion ctrlO = new CtrlOperacion();
                        int stock = ctrlO.stockdisponible(id);
                        txtProducto.setText(pro.getNombre());
                        txtPrecio.setText(""+pro.getPre_salida());
                        txtStock.setText(""+stock);
                        txtCantidad.setText("1");
                        float precio = Float.parseFloat(txtPrecio.getText());
                        int cantidad = Integer.parseInt(txtCantidad.getText());
                        String total = ""+precio*cantidad;
                        txtTotal.setText(total);
                        txtCantidad.requestFocus();
                    }

                }else{
                    JOptionPane.showMessageDialog(null, "No se a ingresado ningun dato");
                    txtBuscar.requestFocus();
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No tiene acceso a esta funcion");
        }
    }
    
    void Estructura(){
        modelo = new DefaultTableModel();
        tblVenta.setModel(modelo);
        //Nombre de las Columnas
        modelo.addColumn("Id");
        modelo.addColumn("Producto");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Total");
        //Definir ancho
        int[] anchos = {0,200,100,100};
        int cantidadColumnas = 4;
        for(int x = 1; x < cantidadColumnas; x++){
            tblVenta.getColumnModel().getColumn(x).setPreferredWidth(anchos[x]);
        }
        //Ocultar Columna
        tblVenta.getColumnModel().getColumn(0).setMaxWidth(0);
        tblVenta.getColumnModel().getColumn(0).setMinWidth(0);
        tblVenta.getTableHeader().getColumnModel().getColumn(0).setMaxWidth(0);
        tblVenta.getTableHeader().getColumnModel().getColumn(0).setMinWidth(0);
    }
    
    void agregarTabla(){
        //Ingreso de Datos
        try {
            int idProd = Integer.parseInt(txtis.getText());
            String prod = txtProducto.getText();
            int disponible = Integer.parseInt(txtStock.getText());
            int cantidad = Integer.parseInt(txtCantidad.getText());
            double total = Double.parseDouble(txtTotal.getText());
            //Array que guarda los datos a la tabla
            ArrayList lista = new ArrayList();
            if(disponible>0){
                if(cantidad>0 && cantidad<=disponible){
                    //guardando valores dentro de lista
                    lista.add(idProd);
                    lista.add(prod);
                    lista.add(cantidad);
                    lista.add(total);
                    //Creando variable objeto y agregando a la tabla
                    Object[] ob = new Object[4];
                    ob[0] = lista.get(0);
                    ob[1] = lista.get(1);
                    ob[2] = lista.get(2);
                    ob[3] = lista.get(3);
                    modelo.addRow(ob);
                    tblVenta.setModel(modelo);
                }else if(cantidad>disponible){
                    JOptionPane.showMessageDialog(null, "Lo solicitado supera el limite de lo que hay en el inventario");
                }
            }else{
                JOptionPane.showMessageDialog(null, "No hay disponibilidad del Producto");
            }
            limpiar();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se a seleccionado ningun producto");
        }
        
    }
    
    void calcularTotal(){
        //Asignar variable
        tPagar = 0;
        //Calcular el total de la compra
        for (int i = 0; i < tblVenta.getRowCount(); i++) {
            Float pre = Float.parseFloat(tblVenta.getValueAt(i, 3).toString());
            tPagar = tPagar + pre;
        }
        //Mostrar el total en la caja de texto
        txtPagar.setText(""+tPagar);
    }
    
    void limpiar(){
        txtBuscar.setText("");
        txtis.setText("");
        txtProducto.setText("");
        txtPrecio.setText("0");
        txtStock.setText("");
        txtCantidad.setText("0");
        txtTotal.setText("");
        txtBuscar.requestFocus();
    }
    
    void eliminarFila(){
        int fila = tblVenta.getSelectedRow();
        if(fila>0){
            modelo.removeRow(fila);
            calcularTotal();
        }
    }
    
    void CancelarVen(){
        int fila = modelo.getRowCount();
        for (int i = fila-1; i >= 0; i--) {
            modelo.removeRow(i);
        }
        limpiar();
    }
    
    void guardarVenta(){
        
    }
    
    void obtenerDatos(){
        try {
            String obtener = txtPagar.getText();
            if(!"0.0".equals(obtener)){
                String obtene = txtEfectivo.getText();
                tPagar = Double.parseDouble(obtener);//obtener total
                if(!"".equals(obtene)){
                    efectivo = Integer.parseInt(obtene);//Obtiene efectivo
                    if(efectivo>=tPagar){
                        String obten = txtDescuento.getText();
                        if(!"0".equals(obten)){
                            descuento = Integer.parseInt(obten);
                        }
                        double devolver = efectivo-(tPagar-descuento);
                        totalV = efectivo-(efectivo-(tPagar-descuento));
                        JOptionPane.showMessageDialog(null, "El cambio es:\n$"+devolver);
                        System.out.println(totalV);
                    }else{
                        JOptionPane.showMessageDialog(null, "El valor ingresado es invalido");
                        txtEfectivo.setText("");
                        txtEfectivo.requestFocus();
                    }
                    
                }else{
                    JOptionPane.showMessageDialog(null, "Agregar efectivo");
                    txtEfectivo.requestFocus();
                }
            }else{
                JOptionPane.showMessageDialog(null, "No se han Agregado Productos");
                txtBuscar.requestFocus();
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    void registrarVenta(){
        String codV = txtCodVenta.getText();
        int idU = usu.getId();
        Venta ven = new Venta();
        ven.setCod_venta(codV);
        ven.setId_usuario(idU);
        ven.setTotal(tPagar);
        ven.setEfectivo(efectivo);
        ven.setDescuento(descuento);
        ConsVenta conV = new ConsVenta();
        conV.registrarVenta(ven);
    }
    
    void registrarOperacion(){
        int idV = ctrlO.ObtenerIdVenta();
        int operation = 2;
        Operacion ope = new Operacion();
        for (int i = 0; i < tblVenta.getRowCount(); i++) {
            int idP = Integer.parseInt(tblVenta.getValueAt(i, 0).toString());
            int q = Integer.parseInt(tblVenta.getValueAt(i, 2).toString());
            ope.setId_producto(idP);
            ope.setQ(q);
            ope.setId_tipooperacion(operation);
            ope.setId_venta(idV);
            ConsOperacion consO = new ConsOperacion();
            consO.registrarVenta(ope);
        }
        JOptionPane.showMessageDialog(null, "Venta Registrada");
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmVenta.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmVenta().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAgregar;
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JTable tblVenta;
    private javax.swing.JTextField txtBuscar;
    private javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtCodVenta;
    private javax.swing.JTextField txtDescuento;
    private javax.swing.JTextField txtEfectivo;
    private javax.swing.JTextField txtPagar;
    private javax.swing.JTextField txtPrecio;
    private javax.swing.JTextField txtProducto;
    private javax.swing.JTextField txtStock;
    private javax.swing.JTextField txtTotal;
    private javax.swing.JTextField txtis;
    // End of variables declaration//GEN-END:variables
}
