package Vista;

import Modelo.Conexion;
import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.util.JRLoader;
import net.sf.jasperreports.view.JasperViewer;

public class frmReporteP extends javax.swing.JFrame {

    Usuario usu;
    public frmReporteP() {
        initComponents();
    }
    
    public frmReporteP(Usuario usu) {
        initComponents();
        this.usu = usu;
        fechaActual();
        jDFinal.requestFocus();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnVentaGen = new javax.swing.JButton();
        btnInventario = new javax.swing.JButton();
        btnProducto = new javax.swing.JButton();
        jDInicio = new com.toedter.calendar.JDateChooser();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jDFinal = new com.toedter.calendar.JDateChooser();
        btnVencimiento = new javax.swing.JButton();
        btnProveedor = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setIconImages(null);
        setResizable(false);

        btnVentaGen.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnVentaGen.setText("<html><center>Generar Reporte<p>Venta General<html>");
        btnVentaGen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentaGenActionPerformed(evt);
            }
        });

        btnInventario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnInventario.setText("<html><center>Generar Reporte<p>Inventario<html>");
        btnInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInventarioActionPerformed(evt);
            }
        });

        btnProducto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnProducto.setText("<html><center>Generar Reporte<p>Productos<html>");
        btnProducto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductoActionPerformed(evt);
            }
        });

        jDInicio.setDateFormatString("dd/MM/yyyy");
        jDInicio.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Fecha de inicio");

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel3.setText("Modulo de Reporte");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Fecha Final");

        jDFinal.setDateFormatString("dd/MM/yyyy");
        jDFinal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        btnVencimiento.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnVencimiento.setText("<html><center>Generar Reporte <p>Vencimiento de Productos<html>");
        btnVencimiento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVencimientoActionPerformed(evt);
            }
        });

        btnProveedor.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnProveedor.setText("<html><center>Generar Reporte<p>Proveedores<html>");
        btnProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProveedorActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("<html><center>Generar Reporte <p>Usuario<html>");
        jButton1.setMinimumSize(new java.awt.Dimension(109, 43));
        jButton1.setName(""); // NOI18N
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(189, 189, 189)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(79, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addGap(12, 12, 12)
                        .addComponent(jDInicio, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addComponent(jLabel4)
                        .addGap(14, 14, 14)
                        .addComponent(jDFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(44, 44, 44)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(btnProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnVentaGen, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(92, 92, 92)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnInventario)
                            .addComponent(btnVencimiento)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(28, 28, 28)))
                .addGap(74, 74, 74))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(jLabel3)
                .addGap(39, 39, 39)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(jDInicio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jDFinal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnVentaGen, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnInventario, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnProducto, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnProveedor, javax.swing.GroupLayout.DEFAULT_SIZE, 68, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(92, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnVentaGenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentaGenActionPerformed
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Date date = jDInicio.getDate();
                long d = date.getTime();
                java.sql.Date fecha = new java.sql.Date(d);
                String f = fecha.toString();//Fe
                if(f != null || f != ""){
                    Date date1 = jDFinal.getDate();
                    long d1 = date1.getTime();
                    java.sql.Date fecha1 = new java.sql.Date(d1);
                    String f1 = fecha1.toString();
                    if(f1 != null || f1 != ""){
                        ventaGeneral(f, f1);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Campo incorrecto, ingrese un valor valido");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Campos vacios. llenar los campos de fecha");
        }
    }//GEN-LAST:event_btnVentaGenActionPerformed

    private void btnInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventarioActionPerformed
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Date date = jDInicio.getDate();
                long d = date.getTime();
                java.sql.Date fecha = new java.sql.Date(d);
                String f = fecha.toString();//Fe
                if(f != null || f != ""){
                    Date date1 = jDFinal.getDate();
                    long d1 = date1.getTime();
                    java.sql.Date fecha1 = new java.sql.Date(d1);
                    String f1 = fecha1.toString();
                    if(f1 != null || f1 != ""){
                        inventarioG(f, f1);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Campo incorrecto, ingrese un valor valido");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Campos vacios. llenar los campos de fecha");
        }
    }//GEN-LAST:event_btnInventarioActionPerformed

    private void btnProductoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductoActionPerformed
        productos();
    }//GEN-LAST:event_btnProductoActionPerformed

    private void btnVencimientoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVencimientoActionPerformed
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Date date = jDInicio.getDate();
                long d = date.getTime();
                java.sql.Date fecha = new java.sql.Date(d);
                String f = fecha.toString();//Fe
                if(f != null || f != ""){
                    Date date1 = jDFinal.getDate();
                    long d1 = date1.getTime();
                    java.sql.Date fecha1 = new java.sql.Date(d1);
                    String f1 = fecha1.toString();
                    if(f1 != null || f1 != ""){
                        venciPro(f, f1);
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Campo incorrecto, ingrese un valor valido");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Campos vacios. llenar los campos de fecha");
        }
    }//GEN-LAST:event_btnVencimientoActionPerformed

    private void btnProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProveedorActionPerformed
        proveedor();
    }//GEN-LAST:event_btnProveedorActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        usuario();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void fechaActual(){
        if(usu.getTipo()==1 || usu.getTipo()==2){
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            String sql = "select curdate()";
            try {
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();
                if(rs.next()){
                    Date fecha = rs.getDate(1);
                    jDInicio.setDate(fecha);
                }
            } catch (SQLException ex) {
                Logger.getLogger(frmReporteP.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    private void ventaGeneral(String i,String f){
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Conexion conn = new Conexion();
                Connection con = conn.getConexion();

                JasperReport reporte = null;
//                String path = "\\reportes\\Ventas.jasper";

                Map parametro = new HashMap();
                parametro.put("fecha_inicio",i);
                parametro.put("fecha_final",f);
                //Ubicacion del reporte
                reporte = (JasperReport) JRLoader.loadObject(getClass().getResource("/reportes/Ventas.jasper"));
                //
                JasperPrint jprint = JasperFillManager.fillReport(reporte,parametro,con);
                //Vista Reporte
                JasperViewer view = new JasperViewer(jprint,false);
                //cierre del reporte
                view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                //mostrar reporte
                view.setVisible(true);
            }
        } catch (JRException ex) {
            Logger.getLogger(frmReporteP.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
        }
    }
    
    private void inventarioG(String i,String f){
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Conexion conn = new Conexion();
                Connection con = conn.getConexion();

                JasperReport reporte = null;
//                String path = "src\\reportes\\Inventario.jasper";

                Map parametro = new HashMap();
                parametro.put("fecha_inicio",i);
                parametro.put("fecha_final",f);
                //Ubicacion del reporte
                reporte = (JasperReport) JRLoader.loadObject(getClass().getResource("/reportes/Inventario.jasper"));
                //
                JasperPrint jprint = JasperFillManager.fillReport(reporte,parametro,con);
                //Vista Reporte
                JasperViewer view = new JasperViewer(jprint,false);
                //cierre del reporte
                view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                //mostrar reporte
                view.setVisible(true);
            }
        } catch (JRException ex) {
            Logger.getLogger(frmReporteP.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
        }
    }
    
    private void productos(){
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Conexion conn = new Conexion();
                Connection con = conn.getConexion();

                JasperReport reporte = null;
//                String path = "src\\reportes\\Producto.jasper";

                //Ubicacion del reporte
                reporte = (JasperReport) JRLoader.loadObject(getClass().getResource("/reportes/Producto.jasper"));
                //Enviando datos
                JasperPrint jprint = JasperFillManager.fillReport(reporte,null,con);
                //Vista Reporte
                JasperViewer view = new JasperViewer(jprint,false);
                //cierre del reporte
                view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                //mostrar reporte
                view.setVisible(true);
            }
        } catch (JRException ex) {
            Logger.getLogger(frmReporteP.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
        }
    }
    
    private void venciPro(String i,String f){
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Conexion conn = new Conexion();
                Connection con = conn.getConexion();

                JasperReport reporte = null;
//                String path = "src\\reportes\\Vencimiento.jasper";

                Map parametro = new HashMap();
                parametro.put("fecha_inicio",i);
                parametro.put("fecha_final",f);
                //Ubicacion del reporte
                reporte = (JasperReport) JRLoader.loadObject(getClass().getResource("/reportes/Vencimiento.jasper"));
                //
                JasperPrint jprint = JasperFillManager.fillReport(reporte,parametro,con);
                //Vista Reporte
                JasperViewer view = new JasperViewer(jprint,false);
                //cierre del reporte
                view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                //mostrar reporte
                view.setVisible(true);
            }
        } catch (JRException ex) {
            Logger.getLogger(frmReporteP.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
        }
    }
    
    private void proveedor(){
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Conexion conn = new Conexion();
                Connection con = conn.getConexion();

                JasperReport reporte = null;
//                String path = "src\\reportes\\Proveedor.jasper";

                //Ubicacion del reporte
                reporte = (JasperReport) JRLoader.loadObject(getClass().getResource("/reportes/Proveedor.jasper"));
                //Enviando datos
                JasperPrint jprint = JasperFillManager.fillReport(reporte,null,con);
                //Vista Reporte
                JasperViewer view = new JasperViewer(jprint,false);
                //cierre del reporte
                view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                //mostrar reporte
                view.setVisible(true);
            }
        } catch (JRException ex) {
            Logger.getLogger(frmReporteP.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
        }
    }
    
    private void usuario(){
        try {
            if(usu.getTipo()==1 || usu.getTipo()==2){
                Conexion conn = new Conexion();
                Connection con = conn.getConexion();

                JasperReport reporte = null;
//                String path = "src\\reportes\\Usuario.jasper";

                //Ubicacion del reporte
                reporte = (JasperReport) JRLoader.loadObject(getClass().getResource("/reportes/Usuario.jasper"));
                //Enviando datos
                JasperPrint jprint = JasperFillManager.fillReport(reporte,null,con);
                //Vista Reporte
                JasperViewer view = new JasperViewer(jprint,false);
                //cierre del reporte
                view.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
                //mostrar reporte
                view.setVisible(true);
            }
        } catch (JRException ex) {
            Logger.getLogger(frmReporteP.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println(ex);
        }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmReporteP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmReporteP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmReporteP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmReporteP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmReporteP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnInventario;
    private javax.swing.JButton btnProducto;
    private javax.swing.JButton btnProveedor;
    private javax.swing.JButton btnVencimiento;
    private javax.swing.JButton btnVentaGen;
    private javax.swing.JButton jButton1;
    private com.toedter.calendar.JDateChooser jDFinal;
    private com.toedter.calendar.JDateChooser jDInicio;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    // End of variables declaration//GEN-END:variables
}
