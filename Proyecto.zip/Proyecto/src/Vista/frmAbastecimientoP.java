package Vista;

import Controlador.CtrlInventario;
import Controlador.CtrlOperacion;
import Modelo.Conexion;
import Modelo.Usuario;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;


public class frmAbastecimientoP extends javax.swing.JFrame {

    Usuario usu;
    public static frmAbastecimientoR frmR;
    public static frmAbastecimientoReg frmRe;
    public frmAbastecimientoP() {
        initComponents();
    }
    
    public frmAbastecimientoP(Usuario usu) {
        initComponents();
        this.usu = usu;
        BuscarProducto();
    }
    
    String[] botones ={"Si","No"}; 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCampo = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProducto = new javax.swing.JTable();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btnVaciar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        setSize(new java.awt.Dimension(700, 400));
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Modulo de Inventario");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Buscar Producto");

        txtCampo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtCampo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCampoKeyPressed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Buscar");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        tblProducto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Producto", "Precio de Entrada", "Cantidad Actual"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.Double.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblProducto);

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Agregar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton3.setText("Ver Registros");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        btnVaciar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnVaciar.setText("Vaciar Inventario");
        btnVaciar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVaciarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jLabel2)
                        .addGap(10, 10, 10)
                        .addComponent(txtCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(jButton1))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(76, 76, 76)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnVaciar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(jLabel1)
                .addGap(46, 46, 46)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(txtCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jButton1))
                .addGap(11, 11, 11)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(11, 11, 11)
                        .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnVaciar, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(75, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtCampoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCampoKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            BuscarProducto();
        }
    }//GEN-LAST:event_txtCampoKeyPressed

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        BuscarProducto();
    }//GEN-LAST:event_jButton1MouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        frmHome.frmAP = null;
    }//GEN-LAST:event_formWindowClosing

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        try {
            if(frmRe == null && (usu.getTipo() == 1 || usu.getTipo() == 2)){
                frmRe = new frmAbastecimientoReg(usu);
                frmRe.setVisible(true);
                frmRe.setTitle("Registros de Abastecimientos");
                frmRe.setLocationRelativeTo(null);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Funcion no valida");
        }
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnVaciarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVaciarActionPerformed
        try {
            if(usu.getTipo() == 1){
                CtrlInventario ctrlI = new CtrlInventario();
                int fila = tblProducto.getSelectedRow();
                int id = (int) tblProducto.getValueAt(fila, 0);
                String producto = tblProducto.getValueAt(fila, 1).toString();
                ArrayList<String> idVentas = new ArrayList<>();
                idVentas = ctrlI.idsVenta(id);
                System.out.println(idVentas+" gato");
                
                int i =JOptionPane.showOptionDialog(null, "Seguro desea Vaciar el Producto"+producto+"\n al eliminarlo no podra recuperar la informacion","Mensaje de Confirmacion", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, botones, botones[0]);

                if(i == 0){
                    try {
                        Conexion conn = new Conexion();
                        Connection con = conn.getConexion();
                        PreparedStatement ps;
                        ps = con.prepareStatement("delete from operacion where id_producto = ? and id_tipooperacion=1");
                        ps.setInt(1, id);
                        ps.execute();
                        ps.close();
                        int cont = 0;
                        while(idVentas.get(cont) != null){
                            ps = con.prepareStatement("delete from venta where id = ?");
                            ps.setInt(1, Integer.parseInt(idVentas.get(cont)));
                            ps.execute();
                            ps.close();
                            cont++;
                        }
                        JOptionPane.showMessageDialog(null, "Eliminado con exito");
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
            }else if(usu.getTipo() == 2){
                JOptionPane.showMessageDialog(null, "Funcion no disponible");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una opcion");
            System.out.println(e);
        }
    }//GEN-LAST:event_btnVaciarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            if(frmR == null && (usu.getTipo() == 1 || usu.getTipo() == 2)){
                int fila = tblProducto.getSelectedRow();
                int codigo = (int) tblProducto.getValueAt(fila, 0);
                double dato = (double) tblProducto.getValueAt(fila, 2);
                int pre = (int) dato;
                frmR = new frmAbastecimientoR(codigo,pre,usu);
                frmR.setVisible(true);
                frmR.setTitle("Abastecer Producto");
                frmR.setLocationRelativeTo(null);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccionar una fila");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    void BuscarProducto(){
        try {
            if(usu.getTipo() == 1 || usu.getTipo() == 2){
                String campo = txtCampo.getText();
                String where = "";

                if(!"".equals(campo)){
                    where = "where cod_barras like '%"+campo+"%' or nombre like '%"+campo+"%'";
                }

                Conexion conn = new Conexion();
                Connection con = conn.getConexion();
                PreparedStatement ps;
                ResultSet rs;

                CtrlOperacion ctrlO = new CtrlOperacion();
                DefaultTableModel modelo = new DefaultTableModel();
                tblProducto.setModel(modelo);
                String sql = "select id,nombre,pre_entrada from producto "+where+" limit 20";
                try {
                    ps = con.prepareStatement(sql);
                    rs = ps.executeQuery();

                    ResultSetMetaData rsMd = rs.getMetaData();
                    int cantidadColumnas = rsMd.getColumnCount();

                    modelo.addColumn("Id");
                    modelo.addColumn("Producto");
                    modelo.addColumn("Precio Entrada");
                    modelo.addColumn("Cantidad Actual");

                    int[] anchos = {0,250,101,101};

                    for(int x = 0; x < cantidadColumnas+1; x++){
                        tblProducto.getColumnModel().getColumn(x).setPreferredWidth(anchos[x]);
                    }
                    //Ocultar Columna
                    tblProducto.getColumnModel().getColumn(0).setMaxWidth(0);
                    tblProducto.getColumnModel().getColumn(0).setMinWidth(0);
                    tblProducto.getTableHeader().getColumnModel().getColumn(0).setMaxWidth(0);
                    tblProducto.getTableHeader().getColumnModel().getColumn(0).setMinWidth(0);

                    while(rs.next()){

                        Object[] fila = new Object[cantidadColumnas+1];
                        for(int i = 0; i < cantidadColumnas; i++){
                            fila[i] = rs.getObject(i+1);
                        }
                        int id = (int) fila[0];
                        int stock = ctrlO.stockdisponible(id);
                        
                        fila[3] = stock;

                        modelo.addRow(fila);

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Funcion no valida","Alerta",2);
        }
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmAbastecimientoP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnVaciar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblProducto;
    private javax.swing.JTextField txtCampo;
    // End of variables declaration//GEN-END:variables
}
