package Vista;

import Controlador.CtrlInventario;
import Modelo.Conexion;
import Modelo.Usuario;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmAbastecimientoReg extends javax.swing.JFrame {

    Usuario usu;
    public static frmAbastecimientoM frmM;
    public frmAbastecimientoReg() {
        initComponents();
    }
    
    public frmAbastecimientoReg(Usuario usu) {
        initComponents();
        this.usu = usu;
        cargar();
    }
    
    String[] botones ={"Si","No"}; 

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblRegistro = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        txtCampo = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Registro de Ingreso de Producto");

        tblRegistro.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblRegistro.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblRegistro);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Nombre del Producto");

        txtCampo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtCampo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCampoKeyPressed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Modificar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Eliminar");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(62, 62, 62)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtCampo)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBuscar))
                    .addComponent(jScrollPane1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(186, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 608, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(105, 105, 105))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 47, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnBuscar)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(64, 64, 64))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        cargar();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void txtCampoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCampoKeyPressed
        if(evt.getKeyCode() == KeyEvent.VK_ENTER){
            cargar();
        }
    }//GEN-LAST:event_txtCampoKeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            if(frmM == null && (usu.getTipo() == 1)){
                int fila = tblRegistro.getSelectedRow();
                String nombre = tblRegistro.getValueAt(fila, 1).toString();
                System.out.println(nombre);
                String cod = tblRegistro.getValueAt(fila, 0).toString();
                System.out.println(cod);
                int can = (int) tblRegistro.getValueAt(fila, 2);
                frmM = new frmAbastecimientoM(nombre, cod,can, usu);
                frmM.setTitle("Modificar Abastecimiento");
                frmM.setLocationRelativeTo(null);
                frmM.setVisible(true);
            }else if(frmM == null && (usu.getTipo() == 2)){
                JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para usar esta funcion","Informacion del Sistema", 2);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una opcion");
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            if(usu.getTipo() == 1){
                int fila = tblRegistro.getSelectedRow();
                String laboratorio = tblRegistro.getValueAt(fila, 0).toString();
                CtrlInventario ctrlI = new CtrlInventario();
                
                int id = ctrlI.idVenta(laboratorio);
                int i =JOptionPane.showOptionDialog(null, "Seguro desea eliminar el Registro"+laboratorio,"Mensaje de Confirmacion", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, botones, botones[0]);

                if(i == 0){
                    try {
                        Conexion conn = new Conexion();
                        Connection con = conn.getConexion();
                        PreparedStatement ps;
                        ps = con.prepareStatement("delete from operacion where id_venta = ?");
                        ps.setInt(1, id);
                        ps.execute();
                        ps.close();
                        ps = con.prepareStatement("delete from venta where id = ?");
                        ps.setInt(1, id);
                        ps.execute();
                        ps.close();
                        JOptionPane.showMessageDialog(null, "Eliminado con exito");
                        cargar();
                    } catch (Exception e) {
                        System.out.println(e);
                    }
                }
            }else if(usu.getTipo() == 2){
                JOptionPane.showMessageDialog(null, "Funcion no disponible");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una opcion");
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        frmAbastecimientoP.frmRe=null;
    }//GEN-LAST:event_formWindowClosing

    private void cargar(){
        
        String campo = txtCampo.getText();
        String where = "where cod_venta like 'A%'";
        
        if(!"".equals(campo)){
            where = where+" and p.nombre like '%"+campo+"%' ";
        }
        
        DefaultTableModel modelo = new DefaultTableModel();
        tblRegistro.setModel(modelo);

        modelo.addColumn("Codigo de Ingreso");
        modelo.addColumn("Producto");
        modelo.addColumn("Cantidad");
        modelo.addColumn("Laboratorio");
        modelo.addColumn("Fecha");

        int[] columnas = {110,190,70,150,170};//590
        for (int i = 0; i < 5; i++) {
            tblRegistro.getColumnModel().getColumn(i).setPreferredWidth(columnas[i]);
        }
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            
            String sql = "select v.cod_venta,p.nombre,o.q,v.fecha,pr.laboratorio from ((venta as v inner join operacion as o on o.id_venta = v.id) inner join producto as p on o.id_producto=p.id) inner join proveedor pr on v.id_proveedor=pr.id "+where+" order by cod_venta";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Object[] lista = new Object[5];
                lista[0] = rs.getString(1);
                lista[1] = rs.getString(2);
                lista[2] = rs.getInt(3);
                lista[3] = rs.getString(5);
                lista[4] = rs.getString(4);
                modelo.addRow(lista);
            }
        } catch (SQLException ex) {
            Logger.getLogger(frmAbastecimientoReg.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmAbastecimientoReg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmAbastecimientoReg().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblRegistro;
    private javax.swing.JTextField txtCampo;
    // End of variables declaration//GEN-END:variables
}
