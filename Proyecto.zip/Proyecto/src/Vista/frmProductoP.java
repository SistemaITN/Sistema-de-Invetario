package Vista;

import Modelo.Conexion;
import Modelo.ConsProveedor;
import Modelo.Producto;
import Modelo.Usuario;
import java.awt.event.KeyEvent;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class frmProductoP extends javax.swing.JFrame {

    Conexion conn = new Conexion();
    Connection con = conn.getConexion();
    PreparedStatement ps;
    ResultSet rs;
    
    Usuario usu;
    public static frmProductoB frmB;
    public static frmProductoM frmM;
    public static frmProductoR frmR;
    public static frmProductoV frmV;
    
    public frmProductoP() {
        initComponents();
    }
    
    public frmProductoP(Usuario usu){
        initComponents();
        this.usu = usu;
        Buscar();
    }

    String[] botones ={"Si","No"};
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtCampo = new javax.swing.JTextField();
        btnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblProducto = new javax.swing.JTable();
        btnVisualizar = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 48)); // NOI18N
        jLabel1.setText("Modulo de Producto");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Codigo Barras/ Nombre Producto");

        txtCampo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtCampo.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                txtCampoKeyPressed(evt);
            }
        });

        btnBuscar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBuscar.setText("Buscar");
        btnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarActionPerformed(evt);
            }
        });

        tblProducto.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo de Barras", "Nombre", "Presentacion", "Precio", "Farmacologia"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblProducto);

        btnVisualizar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnVisualizar.setText("Visualizar");
        btnVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVisualizarActionPerformed(evt);
            }
        });

        btnModificar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnModificar.setText("Modificar");
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnEliminar.setText("Eliminar");
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Registrar");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton2.setText("Listar Productos");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(52, 52, 52)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 319, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnBuscar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2))
                    .addComponent(jScrollPane1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnVisualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnModificar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addGap(37, 37, 37))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(232, 232, 232))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(jLabel1)
                .addGap(43, 43, 43)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel2)
                                    .addComponent(txtCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 2, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(btnBuscar)))
                        .addGap(7, 7, 7)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 234, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnVisualizar, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)))
                .addContainerGap(48, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarActionPerformed
        Buscar();
    }//GEN-LAST:event_btnBuscarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        try {
            if(usu.getTipo() == 1){
                int fila = tblProducto.getSelectedRow();
                String producto = tblProducto.getValueAt(fila, 1).toString();
                String cod = tblProducto.getValueAt(fila, 0).toString();
                int i =JOptionPane.showOptionDialog(null, "Seguro desea eliminar el Producto "+producto,"Mensaje de Confirmacion", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, botones, botones[0]);

                if(i == 0){
                    try {
                        Conexion conn = new Conexion();
                        Connection con = conn.getConexion();
                        ps = con.prepareStatement("delete from producto where cod_barras = ?");
                        ps.setString(1, cod);
                        ps.execute();
                        JOptionPane.showMessageDialog(null, "Eliminado con exito");
                        Buscar();
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, "Asegurece de vaciar el inventario y eliminar las ventas para eliminar el producto"+e,"Mensaje del Sistema",0);
                    }
                }
            }else if(usu.getTipo() == 2){
                JOptionPane.showMessageDialog(null, "Funcion no disponible");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Seleccione una opcion");
        }
    }//GEN-LAST:event_btnEliminarActionPerformed

    private void txtCampoKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCampoKeyPressed
        if(evt.getKeyCode()==KeyEvent.VK_ENTER){
            updateB();
        }
    }//GEN-LAST:event_txtCampoKeyPressed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            if(frmR == null){
                if(usu.getTipo() == 1 || usu.getTipo()==2){
                    frmR = new frmProductoR();
                    frmR.setVisible(true);
                    frmR.setTitle("Registrar Producto");
                    frmR.setLocationRelativeTo(null);
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        frmHome.frmP = null;
    }//GEN-LAST:event_formWindowClosing

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        try {
            if(frmM == null){
                if(usu.getTipo() == 1){
                    int fila = tblProducto.getSelectedRow();
                    int codigo = (int) tblProducto.getValueAt(fila, 0);
                    int id = consultarId(codigo);
                    frmM = new frmProductoM(id,codigo);
                    frmM.setVisible(true);
                    frmM.setTitle("Modificar Producto");
                    frmM.setLocationRelativeTo(null);
                }else if(usu.getTipo()==2){
                    JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para usar esta funcion");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Seleccione un producto");
        }
    }//GEN-LAST:event_btnModificarActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try {
            if(frmB == null){
                if(usu.getTipo() == 1 || usu.getTipo() == 2){
                    frmB = new frmProductoB();
                    frmB.setVisible(true);
                    frmB.setTitle("Listado de Productos");
                    frmB.setLocationRelativeTo(null);
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    private void btnVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVisualizarActionPerformed
        try {
            if (frmV == null){
                if(usu.getTipo() == 1 || usu.getTipo() == 2){
                    int fila = tblProducto.getSelectedRow();
                    int codigo = (int) tblProducto.getValueAt(fila, 0);
                    int id = consultarId(codigo);
                    frmV = new frmProductoV(id,usu);
                    frmV.setVisible(true);
                    frmV.setTitle("Visualizar Producto");
                    frmV.setLocationRelativeTo(null);
                }else if(usu.getTipo() == 2){
                    JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para usar esta funcion");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,"Seleccione un producto");
        }
    }//GEN-LAST:event_btnVisualizarActionPerformed

    int consultarId(int cod){
        Producto pro = new Producto();
        int id = 0;
        String sql = "select id from producto where cod_barras = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, cod);
            rs = ps.executeQuery();
            while(rs.next()){
                pro.setId(rs.getInt("id"));
            }
            rs.close();
            id = pro.getId();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
        return id;
    }
    
    void Buscar(){
        
        if(usu.getTipo() == 1 || usu.getTipo() == 2){
            String campo = txtCampo.getText();
            String where = "";

            if(!"".equals(campo)){
                where = "where cod_barras = '"+campo+"' or nombre = '"+campo+"'";
            }

            DefaultTableModel modelo = new DefaultTableModel();
            tblProducto.setModel(modelo);
            String sql = "select cod_barras,nombre,presentacion,pre_salida,farmacologia from producto "+where+" limit 20";
            try {
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();

                ResultSetMetaData rsMd = rs.getMetaData();
                int cantidadColumnas = rsMd.getColumnCount();

                modelo.addColumn("Codigo de Barras");
                modelo.addColumn("Nombre");
                modelo.addColumn("Presentacion");
                modelo.addColumn("Precio");
                modelo.addColumn("Farmacologia");

                int[] anchos = {50,150,100,50,50};

                for(int x = 0; x < cantidadColumnas; x++){
                    tblProducto.getColumnModel().getColumn(x).setPreferredWidth(anchos[x]);
                }

                while(rs.next()){

                    Object[] fila = new Object[cantidadColumnas];
                    for(int i = 0; i < cantidadColumnas; i++){
                        fila[i] = rs.getObject(i+1);
                    }

                    modelo.addRow(fila);

                }
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        
    }
    
    void updateB(){
        
        try {
            if(usu.getTipo() == 1 || usu.getTipo() == 2){
                String campo = txtCampo.getText();
                String where = "";

                if(!"".equals(campo)){
                    where = "where cod_barras like '%"+campo+"%' or nombre like '%"+campo+"%'";
                }

                DefaultTableModel modelo = new DefaultTableModel();
                tblProducto.setModel(modelo);

                String sql = "select cod_barras,nombre,presentacion,pre_salida,farmacologia from producto "+where+" limit 20";
                try {
                    ps = con.prepareStatement(sql);
                    rs = ps.executeQuery();

                    ResultSetMetaData rsMd = rs.getMetaData();
                    int cantidadColumnas = rsMd.getColumnCount();

                    modelo.addColumn("Codigo de Barras");
                    modelo.addColumn("Nombre");
                    modelo.addColumn("Presentacion");
                    modelo.addColumn("Precio");
                    modelo.addColumn("Farmacologia");

                    int[] anchos = {50,150,100,50,50};

                    for(int x = 0; x < cantidadColumnas; x++){
                        tblProducto.getColumnModel().getColumn(x).setPreferredWidth(anchos[x]);
                    }

                    while(rs.next()){

                        Object[] fila = new Object[cantidadColumnas];
                        for(int i = 0; i < cantidadColumnas; i++){
                            fila[i] = rs.getObject(i+1);
                        }

                        modelo.addRow(fila);

                    }
                } catch (Exception e) {
                    System.out.println(e);
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error");
        }

    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmProductoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmProductoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmProductoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmProductoP.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmProductoP().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscar;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnVisualizar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblProducto;
    private javax.swing.JTextField txtCampo;
    // End of variables declaration//GEN-END:variables
}
