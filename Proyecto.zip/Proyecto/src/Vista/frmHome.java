package Vista;

import Modelo.Conexion;
import Modelo.ConsHome;
import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author eliana sofia
 */
public class frmHome extends javax.swing.JFrame {

    Usuario usu;
    ConsHome consH;
    public static frmProductoP frmP;
    public static frmVentaP frmV;
    public static frmUsuarioP frmU;
    public static frmProveedorP frmPr;
    public static frmAbastecimientoP frmAP;
    public static frmVencimiento frmVe;
    public static frmdisponible frmD;
    public static frmReporteP frmR;
    String[] botones ={"Ver productos","No"};
    public frmHome() {
        initComponents();
        
        
    }

    public frmHome(Usuario usu){
        initComponents();
        this.setLocationRelativeTo(null);
        this.usu = usu;
        
        lblNombre.setText("BIENVENIDO: "+usu.getNombre());
        lblTipo.setText("Tipo de Cuenta: "+usu.getTipoUser());
        
        consH = new ConsHome();
        btnProducto1.setText("<html><center>Productos:<p>"+consH.cantidadProd()+"<html>");
        btnVenta1.setText("<html><center>Ventas:<p>"+consH.cantidadVentas()+"<html>");
        btnUsuarios1.setText("<html><center>Usuarios:<p>"+consH.cantidadUsu()+"<html>");
        cargarVentas();
        //Productos por vencerse
        if(vencimiento()>0){
            int i =JOptionPane.showOptionDialog(null,"Hay productos que se estan por vencerse.\nSi quiere ver cuales son oprima el boton \"Ver productos\"","Mensaje del Sistema", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, botones, botones[0]);
            if(i==0){
                if(frmVe == null && (usu.getTipo()==1 || usu.getTipo()==2)){
                    frmVe = new frmVencimiento(usu);
                    frmVe.setVisible(true);
                    frmVe.setLocationRelativeTo(null);
                    frmVe.setTitle("Productos por vencerse");
                }
            }
        }
        if(disponible()>0){
            int i =JOptionPane.showOptionDialog(null,"Hay productos que tienen poco inventario.\nSi quiere ver cuales son oprima el boton \"Ver productos\"","Mensaje del Sistema", JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE, null, botones, botones[0]);
            if(i==0){
                if(frmD == null && (usu.getTipo()==1 || usu.getTipo()==2)){
                    frmD = new frmdisponible(usu);
                    frmD.setVisible(true);
                    frmD.setLocationRelativeTo(null);
                    frmD.setTitle("Productos escasos");
                }
            }
        }
        System.out.println(usu.getUsername());
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblNombre = new javax.swing.JLabel();
        lblTipo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        btnProducto1 = new javax.swing.JButton();
        btnVenta1 = new javax.swing.JButton();
        btnUsuarios1 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblVenta = new javax.swing.JTable();
        btnVenta = new javax.swing.JButton();
        btnProductos = new javax.swing.JButton();
        btnInventario = new javax.swing.JButton();
        btnProveedor = new javax.swing.JButton();
        btnUsuarios = new javax.swing.JButton();
        btnRepertes = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        lblNombre.setFont(new java.awt.Font("Tahoma", 3, 18)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        jLabel1.setText("Sistema de Inventarios");

        jLabel2.setFont(new java.awt.Font("Tahoma", 3, 36)); // NOI18N
        jLabel2.setText("Tienda Naturista Nature's Vission");

        btnProducto1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnProducto1.setPreferredSize(new java.awt.Dimension(123, 79));
        btnProducto1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProducto1ActionPerformed(evt);
            }
        });

        btnVenta1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnVenta1.setPreferredSize(new java.awt.Dimension(95, 79));
        btnVenta1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVenta1ActionPerformed(evt);
            }
        });

        btnUsuarios1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnUsuarios1.setPreferredSize(new java.awt.Dimension(111, 79));
        btnUsuarios1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsuarios1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Ultimas Ventas realizadas");

        tblVenta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        tblVenta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Codigo", "Cantidad", "Total", "Usuario"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Double.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tblVenta);

        btnVenta.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnVenta.setText("Ventas");
        btnVenta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVentaActionPerformed(evt);
            }
        });

        btnProductos.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnProductos.setText("Productos");
        btnProductos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProductosActionPerformed(evt);
            }
        });

        btnInventario.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnInventario.setText("Inventario");
        btnInventario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInventarioActionPerformed(evt);
            }
        });

        btnProveedor.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnProveedor.setText("Proveedores");
        btnProveedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProveedorActionPerformed(evt);
            }
        });

        btnUsuarios.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnUsuarios.setText("Usuarios");
        btnUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUsuariosActionPerformed(evt);
            }
        });

        btnRepertes.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnRepertes.setText("Reportes");
        btnRepertes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRepertesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(173, 173, 173)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btnRepertes, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnUsuarios, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnInventario, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnVenta, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnProductos, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 62, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnProducto1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnVenta1, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnUsuarios1, javax.swing.GroupLayout.PREFERRED_SIZE, 183, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(68, 68, 68))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(107, 107, 107))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 624, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(110, 110, 110))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 435, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(199, 199, 199))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(51, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblNombre, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTipo, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnUsuarios1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnVenta1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnProducto1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel3))
                    .addComponent(btnVenta, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProductos, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(btnInventario, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnUsuarios, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRepertes, javax.swing.GroupLayout.PREFERRED_SIZE, 53, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnProducto1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProducto1ActionPerformed
        prod();
    }//GEN-LAST:event_btnProducto1ActionPerformed

    private void btnProductosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProductosActionPerformed
        prod();
    }//GEN-LAST:event_btnProductosActionPerformed

    private void btnVentaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVentaActionPerformed
        vent();
    }//GEN-LAST:event_btnVentaActionPerformed

    private void btnVenta1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVenta1ActionPerformed
        vent();
    }//GEN-LAST:event_btnVenta1ActionPerformed

    private void btnUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsuariosActionPerformed
        usua();
    }//GEN-LAST:event_btnUsuariosActionPerformed

    private void btnUsuarios1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUsuarios1ActionPerformed
        usua();
    }//GEN-LAST:event_btnUsuarios1ActionPerformed

    private void btnProveedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProveedorActionPerformed
        prov();
    }//GEN-LAST:event_btnProveedorActionPerformed

    private void btnInventarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInventarioActionPerformed
        invt();
    }//GEN-LAST:event_btnInventarioActionPerformed

    private void btnRepertesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRepertesActionPerformed
        reporte();
    }//GEN-LAST:event_btnRepertesActionPerformed

    void cargarVentas(){
        if(usu.getTipo() == 1 || usu.getTipo()==2){
            try {
                DefaultTableModel modelo = new DefaultTableModel();
                tblVenta.setModel(modelo);
                Conexion conn = new Conexion();
                Connection con = conn.getConexion();
                PreparedStatement ps;
                ResultSet rs;
                String sql = "select v.id,v.cod_venta,u.nombre,v.total-v.descuento from (venta as v inner join usuario as u on v.id_usuario=u.id) where cod_venta like 'F%' order by v.id desc limit 5";
                ps = con.prepareStatement(sql);
                rs = ps.executeQuery();

                modelo.addColumn("Codigo de venta");
                modelo.addColumn("Cantidad");
                modelo.addColumn("Total");
                modelo.addColumn("Usuario");

                int[] anchos = {125,125,125,125};

                for(int x = 0; x < 3; x++){
                    tblVenta.getColumnModel().getColumn(x).setPreferredWidth(anchos[x]);
                }

                while(rs.next()){
                    String sqlC = "select sum(q) from operacion where id_venta = ?";
                    ResultSet rs1;
                    ps = con.prepareStatement(sqlC);
                    ps.setInt(1, rs.getInt(1));
                    rs1 = ps.executeQuery();
                    if(rs1.next()){
                        Object[] fila = new Object[4];
                        fila[0] = rs.getObject(2);
                        fila[1] = rs1.getObject(1);
                        fila[2] = rs.getObject(4);
                        fila[3] = rs.getObject(3);
                        modelo.addRow(fila);
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(frmHome.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    void prod(){
        if(usu.getTipo() == 1 || usu.getTipo()==2){
            try {
                if(frmP == null && (usu.getTipo()== 1 || usu.getTipo()== 2)){
                    frmP = new frmProductoP(usu);
                    frmP.setVisible(true);
                    frmP.setTitle("Modulo Producto");
                    frmP.setLocationRelativeTo(null);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se puede ingresar al sistema");
            }
        }
    }
    
    void vent(){
        if(usu.getTipo() == 1 || usu.getTipo()==2){
            try {
                if(frmV == null && (usu.getTipo()== 1 || usu.getTipo()== 2)){
                    frmV = new frmVentaP(usu);
                    frmV.setVisible(true);
                    frmV.setTitle("Modulo Venta");
                    frmV.setLocationRelativeTo(null);
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se puede ingresar al sistema");
            }
        }
    }
    
    void usua(){
        if(usu.getTipo() == 1){
            try {
                if(frmU == null && usu.getTipo()== 1){
                    frmU = new frmUsuarioP(usu);
                    frmU.setVisible(true);
                    frmU.setTitle("Modulo Usuario");
                    frmU.setLocationRelativeTo(null);
                }else if(frmU == null && usu.getTipo() == 2){
                    JOptionPane.showMessageDialog(null, "Comuniquese con el Administrador del Sistema para entrar en esta funcion");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se puede ingresar al sistema");
            }
        }else if(usu.getTipo() == 2){
            JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para usar esta funcion");
        }
    }
    
    void prov(){
        if(usu.getTipo() == 1){
            try {
                if(frmPr == null && usu.getTipo()== 1){
                    frmPr = new frmProveedorP(usu);
                    frmPr.setVisible(true);
                    frmPr.setTitle("Modulo Usuario");
                    frmPr.setLocationRelativeTo(null);
                }else if(frmPr == null && usu.getTipo() == 2){
                    JOptionPane.showMessageDialog(null, "Comuniquese con el Administrador del Sistema para entrar en esta funcion");
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "No se puede ingresar al sistema");
            }
        }else if(usu.getTipo() == 2){
            JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para usar esta funcion");
        }
    }
    
    void invt(){
        try {
            if(usu.getTipo() == 1 || usu.getTipo() == 2){
                try {
                    if(frmAP == null && (usu.getTipo()== 1 || usu.getTipo() == 2)){
                        frmAP = new frmAbastecimientoP(usu);
                        frmAP.setVisible(true);
                        frmAP.setTitle("Modulo Inventario");
                        frmAP.setLocationRelativeTo(null);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "No se puede ingresar al sistema");
                }
            }else if(usu.getTipo() == 2){
                JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para usar esta funcion");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    private int vencimiento(){
        int cont = 0;
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            String sql = "select datediff(fec_venc,curdate()) as a from operacion where datediff(fec_venc,curdate()) is not null";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                if(rs.getInt(1)>0 && rs.getInt(1)<31){
                    cont = cont+1;
                }
            }
            rs.close();
            ps.close();
            System.out.println(cont);
            return cont;
        } catch (SQLException ex) {
            Logger.getLogger(frmHome.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error");
            return cont;
        }
    }
    
    private int disponible(){
        int cont = 0;
        try {
            Conexion conn = new Conexion();
            Connection con = conn.getConexion();
            PreparedStatement ps;
            ResultSet rs;
            String sql = "select p.nombre,p.inv_minimo,sum(if(o.id_tipooperacion=1,q,0))-sum(if(o.id_tipooperacion=2,q,0)) from producto as p inner join operacion as o on p.id = o.id_producto group by p.nombre";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                if(rs.getInt(3)<=rs.getInt(2)){
                    cont = cont+1;
                }
            }
            return cont;
        } catch (SQLException ex) {
            Logger.getLogger(frmHome.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error");
            return cont;
        }
    }
    
    void reporte(){
        try {
            if(usu.getTipo() == 1 || usu.getTipo() == 2){
                try {
                    if(frmR == null && (usu.getTipo()== 1 || usu.getTipo() == 2)){
                        frmR = new frmReporteP(usu);
                        frmR.setVisible(true);
                        frmR.setTitle("Modulo Inventario");
                        frmR.setLocationRelativeTo(null);
                    }
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "No se puede ingresar al sistema");
                }
            }else if(usu.getTipo() == 2){
                JOptionPane.showMessageDialog(null, "Comuniquese con el administrador para usar esta funcion");
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmHome.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmHome().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnInventario;
    private javax.swing.JButton btnProducto1;
    private javax.swing.JButton btnProductos;
    private javax.swing.JButton btnProveedor;
    private javax.swing.JButton btnRepertes;
    private javax.swing.JButton btnUsuarios;
    private javax.swing.JButton btnUsuarios1;
    private javax.swing.JButton btnVenta;
    private javax.swing.JButton btnVenta1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNombre;
    private javax.swing.JLabel lblTipo;
    private javax.swing.JTable tblVenta;
    // End of variables declaration//GEN-END:variables
}
