package Vista;

import Controlador.CtrlOperacion;
import Modelo.Conexion;
import Modelo.ConsOperacion;
import Modelo.ConsProducto;
import Modelo.Operacion;
import Modelo.Producto;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class frmProductoM extends javax.swing.JFrame {

    //Producto
    Producto pro = new Producto();
    ConsProducto cons = new ConsProducto();
    //Operacion
    Operacion ope = new Operacion();
    ConsOperacion conso = new ConsOperacion();
    CtrlOperacion ctrlOpe = new CtrlOperacion();
    //Conexion
    Conexion conn = new Conexion();
    Connection con = conn.getConexion();
    //Consultas
    PreparedStatement ps = null;
    ResultSet rs = null;
    
    //Valor
    int valor = 0;
    int cod;
    
    public frmProductoM(int x, int cod) {
        initComponents();
        this.setLocationRelativeTo(null);
        //al ejecutar invisible el campo valin
        valid1.setVisible(false);
        valid2.setVisible(false);
        valid3.setVisible(false);
        valid4.setVisible(false);
        valid5.setVisible(false);
        valid6.setVisible(false);
        txtCategoria.setVisible(true);
        //Obtener Valor
        this.valor = x;
        this.cod = cod;
        cargarProducto(valor);
    }

    int cont;//Contador de campos llenos
    
    public void validar(){
        if(txtBarras.getText().equals("")){valid1.setVisible(true);cont++;}else{valid1.setVisible(false);}
        if(txtNombre.getText().equals("")){valid2.setVisible(true);cont++;}else{valid2.setVisible(false);}
        if(txtEntrada.getText().equals("")){valid3.setVisible(true);cont++;}else{valid3.setVisible(false);}
        if(txtSalida.getText().equals("")){valid4.setVisible(true);cont++;}else{valid4.setVisible(false);}
        if(txtCantidad.getText().equals("")){valid5.setVisible(true);cont++;}else{valid5.setVisible(false);}
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtBarras = new javax.swing.JTextField();
        txtNombre = new javax.swing.JTextField();
        txtInventario = new javax.swing.JTextField();
        txtEntrada = new javax.swing.JTextField();
        txtSalida = new javax.swing.JTextField();
        btnGuardar = new javax.swing.JButton();
        valid1 = new javax.swing.JLabel();
        valid2 = new javax.swing.JLabel();
        valid3 = new javax.swing.JLabel();
        valid4 = new javax.swing.JLabel();
        valid5 = new javax.swing.JLabel();
        valid6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        txtCantidad = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtPresentacion = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        txtCategoria = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        jDVencimiento = new com.toedter.calendar.JDateChooser();

        jLabel8.setText("jLabel8");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Registrar Producto");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("Modificar Producto");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Codigo de Barras:");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Nombre:");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Inventario Minimo:");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Precio de Entrada:");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel6.setText("Precio de Salida:");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Farmacologia:");

        txtBarras.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtBarras.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtBarrasKeyTyped(evt);
            }
        });

        txtNombre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        txtInventario.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtInventario.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtInventarioKeyTyped(evt);
            }
        });

        txtEntrada.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtEntrada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtEntradaKeyTyped(evt);
            }
        });

        txtSalida.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtSalida.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtSalidaKeyTyped(evt);
            }
        });

        btnGuardar.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        btnGuardar.setText("Guardar Cambios");
        btnGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGuardarActionPerformed(evt);
            }
        });

        valid1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valid1.setForeground(new java.awt.Color(255, 0, 0));
        valid1.setText("Requerido");

        valid2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valid2.setForeground(new java.awt.Color(255, 0, 0));
        valid2.setText("Requerido");

        valid3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valid3.setForeground(new java.awt.Color(255, 0, 0));
        valid3.setText("Requerido");

        valid4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valid4.setForeground(new java.awt.Color(255, 0, 0));
        valid4.setText("Requerido");

        valid5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valid5.setForeground(new java.awt.Color(255, 0, 0));
        valid5.setText("Requerido");

        valid6.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        valid6.setForeground(new java.awt.Color(255, 0, 0));
        valid6.setText("Requerido");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Cantidad Inicial:");

        txtCantidad.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtCantidad.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                txtCantidadKeyTyped(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("*En caso de no diligenciar este campo se quedara");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("por defecto con 10 unidades minimas*");

        txtPresentacion.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel12.setText("Presentacion");

        txtCategoria.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jButton1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton1.setText("Cancelar");
        jButton1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButton1MouseClicked(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Fecha de Vencimiento");

        jDVencimiento.setDateFormatString("dd/MM/yyyy");
        jDVencimiento.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(74, 74, 74)
                        .addComponent(btnGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(79, 79, 79))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(84, 84, 84))))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7)
                                    .addComponent(jLabel9))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtCantidad)
                                    .addComponent(txtCategoria)
                                    .addComponent(txtEntrada)
                                    .addComponent(txtSalida))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(valid3)
                                    .addComponent(valid4)
                                    .addComponent(valid5)))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addComponent(jLabel2)
                                                .addGap(21, 21, 21))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                                    .addComponent(jLabel4)
                                                    .addComponent(jLabel3))
                                                .addGap(18, 18, 18)))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel11)
                                            .addComponent(jLabel10)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                                    .addComponent(txtBarras, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 220, Short.MAX_VALUE)
                                                    .addComponent(txtNombre, javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(txtInventario, javax.swing.GroupLayout.Alignment.LEADING))
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                    .addComponent(valid1)
                                                    .addComponent(valid2)))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(35, 35, 35)
                                        .addComponent(jLabel12)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtPresentacion, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel13)
                        .addGap(18, 18, 18)
                        .addComponent(jDVencimiento, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(valid6)))
                .addGap(53, 53, 53))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(47, 47, 47)
                .addComponent(jLabel1)
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtBarras, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(valid1))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtNombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(valid2)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txtInventario, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addComponent(jLabel10)
                .addGap(5, 5, 5)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtPresentacion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtEntrada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(valid3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtSalida, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(valid4)
                            .addComponent(jLabel6))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtCantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9)
                            .addComponent(valid5))
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txtCategoria, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jDVencimiento, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 44, Short.MAX_VALUE)
                            .addComponent(btnGuardar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(53, 53, 53))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(valid6)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGuardarActionPerformed
        try {
            cont=0;
            validar();
            if(cont==0){
                if((Integer.parseInt(txtBarras.getText()) == cod) || cons.existeCod(txtBarras.getText()) == false){
                    //if((cons.existeProducto(txtNombre.getText()) == false) || txtNombre.getText() == nombre){
                        actualizarProducto(valor);
                        frmProductoP.frmM=null;
                        dispose();
//                    }else{
//                        JOptionPane.showMessageDialog(null, "Este nombre ya se encuentra registrado, cambiarlo");
//                        txtNombre.requestFocus();
//                    }
                }else{
                    JOptionPane.showMessageDialog(null, "El codigo de barras "+txtBarras.getText()+" ya existe en el sistema");
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Campos vacios, llenar los campos");
        }
    }//GEN-LAST:event_btnGuardarActionPerformed

    private void txtEntradaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtEntradaKeyTyped
        char c = evt.getKeyChar();//Evento de oprimir una tecla del teclado
        if (c<'0' || c>'9'){//si es diferente a los numeros
            evt.consume();//No colocarlos en pantalla
        }
    }//GEN-LAST:event_txtEntradaKeyTyped

    private void txtSalidaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtSalidaKeyTyped
        char c = evt.getKeyChar();
        if (c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_txtSalidaKeyTyped

    private void txtCantidadKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtCantidadKeyTyped
        char c = evt.getKeyChar();
        if (c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_txtCantidadKeyTyped

    private void txtInventarioKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtInventarioKeyTyped
        char c = evt.getKeyChar();
        if (c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_txtInventarioKeyTyped

    private void jButton1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButton1MouseClicked
        dispose();
        frmProductoP.frmM=null;
    }//GEN-LAST:event_jButton1MouseClicked

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        frmProductoP.frmM=null;
    }//GEN-LAST:event_formWindowClosing

    private void txtBarrasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBarrasKeyTyped
        char c = evt.getKeyChar();
        if (c<'0' || c>'9'){
            evt.consume();
        }
    }//GEN-LAST:event_txtBarrasKeyTyped

    //Funciones
    void actualizarProducto(int id){
        try {
            ps = con.prepareStatement("UPDATE producto SET cod_barras=?,nombre=?,presentacion=?,inv_minimo=?,pre_entrada=?,pre_salida=?,farmacologia=? WHERE id=?");
            ps.setInt(1, Integer.parseInt(txtBarras.getText()));
            ps.setString(2, txtNombre.getText());
            ps.setString(3, txtPresentacion.getText());
            ps.setInt(4, Integer.parseInt(txtInventario.getText()));
            ps.setInt(5, Integer.parseInt(txtEntrada.getText()));
            ps.setInt(6, Integer.parseInt(txtSalida.getText()));
            ps.setString(7, txtCategoria.getText());
            ps.setInt(8, id);
            ps.execute();
            ps.close();
            updateOperation(id);
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }
    
    void updateOperation(int id){
        try {
            ps = con.prepareStatement("UPDATE operacion SET q=?,fec_venc=? WHERE id_producto=? and id_venta is null");
            ps.setInt(1, Integer.parseInt(txtCantidad.getText()));
            //Fecha
            java.util.Date date = jDVencimiento.getDate();
            long d = date.getTime();
            java.sql.Date fecha = new java.sql.Date(d);
            String f = fecha.toString();
            System.out.println(f);
            ps.setString(2, f);
            ps.setInt(3, id);
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Actualizacion Exitosa");
        } catch (Exception e) {
            System.out.println(e.toString()+"Este");
        }
    }
    
    void cargarProducto(int id){
        String sql = "select * from producto where id = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while(rs.next()){
                txtBarras.setText(rs.getString("cod_barras"));
                txtNombre.setText(rs.getString("nombre"));
                txtPresentacion.setText(rs.getString("presentacion"));
                txtInventario.setText(rs.getString("inv_minimo"));
                txtEntrada.setText(rs.getString("pre_entrada"));
                txtSalida.setText(rs.getString("pre_salida"));
                txtCategoria.setText(rs.getString("farmacologia"));
            }
            rs.close();
            cargarOperacion(id);
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    
    void cargarOperacion(int id){
        String sql = "select q,fec_venc from operacion where id_producto = ? and id_venta is null";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while(rs.next()){
                txtCantidad.setText(rs.getString("q"));
                Date date = rs.getDate(2);
                jDVencimiento.setDate(date);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmProductoM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmProductoM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmProductoM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmProductoM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                    //new frmProductoV().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton btnGuardar;
    private javax.swing.JButton jButton1;
    private com.toedter.calendar.JDateChooser jDVencimiento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    public javax.swing.JTextField txtBarras;
    public javax.swing.JTextField txtCantidad;
    private javax.swing.JTextField txtCategoria;
    public javax.swing.JTextField txtEntrada;
    public javax.swing.JTextField txtInventario;
    public javax.swing.JTextField txtNombre;
    private javax.swing.JTextField txtPresentacion;
    public javax.swing.JTextField txtSalida;
    private javax.swing.JLabel valid1;
    private javax.swing.JLabel valid2;
    private javax.swing.JLabel valid3;
    private javax.swing.JLabel valid4;
    private javax.swing.JLabel valid5;
    private javax.swing.JLabel valid6;
    // End of variables declaration//GEN-END:variables
}
