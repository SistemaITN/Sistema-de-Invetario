package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author eliana sofia
 */
public class ConsUsuario extends Conexion{
    
    //Funciones
    public boolean registrar(Usuario1 usu){
        
        //Variables de conexion
        PreparedStatement ps;
        Connection con = getConexion();

        //Script ingreso de datos
        String sql = "insert into usuario(nombre,apellido,username,pass,telefono,email,id_tipousuario) values (?,?,?,?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usu.getNombre());
            ps.setString(2, usu.getApellido());
            ps.setString(3, usu.getUsername());
            ps.setString(4, usu.getPassword());
            ps.setString(5, usu.getTelefono());
            ps.setString(6, usu.getEmail());
            ps.setInt(7, usu.getTipo());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ConsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
        
    }
    
    public boolean login(Usuario usu){
        
        //Variables de conexion
        PreparedStatement ps;
        ResultSet rs;
        Connection con = getConexion();

        //Script ingreso de datos
        String sql = "select u.id,u.username,u.pass,upper(u.nombre),u.id_tipousuario,t.nombre from usuario as u inner join tipo_usuario as t on t.id=u.id_tipousuario where username = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usu.getUsername());
            rs = ps.executeQuery();
            if(rs.next()){
                //Validar Password
                if(usu.getPassword().equals(rs.getString(3))){
                    String sqlUpdate = "update usuario set last_date = ? where id = ?";
                    ps = con.prepareStatement(sqlUpdate);
                    ps.setString(1, usu.getLast());
                    ps.setInt(2, rs.getInt(1));
                    ps.execute();
                    
                    usu.setId(rs.getInt(1));
                    usu.setNombre(rs.getString(4));
                    usu.setTipo(rs.getInt(5));
                    usu.setTipoUser(rs.getString(6));
                    return true;
                }else{
                    return false;
                }
            }
            return false;
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
            Logger.getLogger(ConsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    public int validPass(String pass,String usu){
        int val = 0;
        try {
            //Variables de conexion
            PreparedStatement ps;
            ResultSet rs;
            Connection con = getConexion();
            String sql = "select pass from usuario where username = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, usu);
            rs = ps.executeQuery();
            if(rs.next()){
                if(pass.equals(rs.getString(1))){
                    val = 1;
                }
            }
            return val;
        } catch (SQLException ex) {
            Logger.getLogger(ConsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            return val;
        }
    }
    
    public int passUpdate(String usu,String pass){
        try {
            PreparedStatement ps;
            ResultSet rs;
            Connection con = getConexion();
            String sql = "update usuario set pass = ? where username = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, pass);
            ps.setString(2, usu);
            ps.execute();
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(ConsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    
    public int existeusu(String usu){
        
        //Variables de conexion
        PreparedStatement ps;
        ResultSet rs;
        Connection con = getConexion();

        //Script ingreso de datos
        String sql = "select count(id) from usuario where username = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, usu);
            rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(ConsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        }
    }
    
    public boolean esEmail(String correo){
        //validar patron del email
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@"+"[_A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        Matcher mather = pattern.matcher(correo);
        return mather.find();
    }
    
}
