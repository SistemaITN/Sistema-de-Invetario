package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class ConsProducto extends Conexion{
    Connection con = getConexion();
    PreparedStatement ps;
    ResultSet rs;
    
    int respuesta = 0;
    public int registrar(Producto pro){
        //Script de registro
        String sql = "insert into producto(cod_barras,nombre,presentacion,inv_minimo,pre_entrada,pre_salida,farmacologia,fecha) values(?,?,?,?,?,?,?,now())";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, pro.getBarras());
            ps.setString(2, pro.getNombre());
            ps.setString(3, pro.getPresentacion());
            ps.setInt(4, pro.getInv_minimo());
            ps.setFloat(5, pro.getPre_entrada());
            ps.setFloat(6, pro.getPre_salida());
            ps.setString(7, pro.getFarmacologia());
            ps.execute();
            ps.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al Registrar\nError: "+e);
        }
        return respuesta;
    }
    
    public ArrayList<Producto> Buscar(){
        ArrayList list = new ArrayList();
        //Script Busqueda
        String sql = "select * from producto where 1 order by nombre asc";
        try {
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            while(rs.next()){
                Producto pro = new Producto();
                //Obtener los valores
                pro.setId(rs.getInt("id"));
                pro.setBarras(rs.getInt("cod_barras"));
                pro.setNombre(rs.getString("nombre"));
                pro.setInv_minimo(rs.getInt("inv_minimo"));
                pro.setPre_entrada(rs.getFloat("pre_entrada"));
                pro.setPre_salida(rs.getFloat("pre_salida"));
                pro.setFarmacologia(rs.getString("farmacologia"));
                list.add(pro);
            }
            rs.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        return list;
    }
    
    public Producto identificar(String campo){
        Producto pro = new Producto();
        String sql="select * from producto where cod_barras=? or nombre=?";
        try{
            ps = con.prepareStatement(sql);
            ps.setString(1,campo);
            ps.setString(2,campo);
            rs = ps.executeQuery();
            while(rs.next()){
                pro.setId(rs.getInt("id"));
                pro.setBarras(rs.getInt("cod_barras"));
                pro.setNombre(rs.getString("nombre"));
                pro.setPresentacion(rs.getString("presentacion"));
                pro.setInv_minimo(rs.getInt("inv_minimo"));
                pro.setPre_entrada(rs.getInt("pre_entrada"));
                pro.setPre_salida(rs.getInt("pre_salida"));
                pro.setFarmacologia(rs.getString("farmacologia"));
            }
        }catch(Exception e){
            System.out.println(e);
        }
        return pro;
    }
    
    public boolean existeProducto(String nom){
        boolean exis = false;
        try {
            String sql  = "select id from producto where nombre = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, nom);
            rs = ps.executeQuery();
            if(rs.next()){
                System.out.println(rs.getInt(1));
                if(rs.getString(1) != null){
                    exis = true;
                }
            }
            System.out.println(exis);
            return exis;
        } catch (SQLException ex) {
            Logger.getLogger(ConsProducto.class.getName()).log(Level.SEVERE, null, ex);
            return exis;
        }
    }
    
    public boolean existeCod(String cod){
        boolean exis = false;
        try {
            String sql  = "select id from producto where cod_barras = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, cod);
            rs = ps.executeQuery();
            if(rs.next()){
                System.out.println(rs.getInt(1));
                if(rs.getString(1) != null){
                    exis = true;
                }
            }
            System.out.println(exis);
            return exis;
        } catch (SQLException ex) {
            Logger.getLogger(ConsProducto.class.getName()).log(Level.SEVERE, null, ex);
            return exis;
        }
    }
}
