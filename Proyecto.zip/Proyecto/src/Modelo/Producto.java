package Modelo;

public class Producto {
    
    //Variables
    private int id;
    private int barras;
    private String nombre;
    private String presentacion;
    private int inv_minimo;
    private float pre_entrada;
    private float pre_salida;
    private String Farmacologia;
    
    
    //Constructor

    public Producto() {
    }

    public Producto(int id, int barras, String nombre, String presentacion, int inv_minimo, float pre_entrada, float pre_salida, String Farmacologia) {
        this.id = id;
        this.barras = barras;
        this.nombre = nombre;
        this.presentacion = presentacion;
        this.inv_minimo = inv_minimo;
        this.pre_entrada = pre_entrada;
        this.pre_salida = pre_salida;
        this.Farmacologia = Farmacologia;
    }

    //Metodos Get y Set

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBarras() {
        return barras;
    }

    public void setBarras(int barras) {
        this.barras = barras;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getInv_minimo() {
        return inv_minimo;
    }

    public void setInv_minimo(int inv_minimo) {
        this.inv_minimo = inv_minimo;
    }

    public float getPre_entrada() {
        return pre_entrada;
    }

    public void setPre_entrada(float pre_entrada) {
        this.pre_entrada = pre_entrada;
    }

    public float getPre_salida() {
        return pre_salida;
    }

    public void setPre_salida(float pre_salida) {
        this.pre_salida = pre_salida;
    }

    public String getFarmacologia() {
        return Farmacologia;
    }

    public void setFarmacologia(String Farmacologia) {
        this.Farmacologia = Farmacologia;
    }

    public String getPresentacion() {
        return presentacion;
    }

    public void setPresentacion(String presentacion) {
        this.presentacion = presentacion;
    }
    
    

}
