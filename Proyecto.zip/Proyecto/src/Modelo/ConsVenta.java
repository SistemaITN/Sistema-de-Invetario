package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Marcela
 */
public class ConsVenta extends Conexion{
    
    //Variables
    Connection con = getConexion();
    //Consultas
    PreparedStatement ps;
    ResultSet rs;
    
    //Funciones
    int respuesta = 0;
    public int registrarVenta(Venta ven){
        //Script de registro
        String sql = "insert into venta(cod_venta,id_usuario,total,efectivo,descuento,fecha) values(?,?,?,?,?,now())";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ven.getCod_venta());
            ps.setInt(2, ven.getId_usuario());
            ps.setDouble(3, ven.getTotal());
            ps.setDouble(4, ven.getEfectivo());
            ps.setDouble(5, ven.getDescuento());
            ps.execute();
            ps.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo registrar la venta\nError: "+e);
        }
        return respuesta;
    }
    
    public int registrarAbas(Venta ven){
        //Script de registro
        String sql = "insert into venta(cod_venta,id_usuario,total,fecha) values(?,?,?,?,?,now())";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, ven.getCod_venta());
            ps.setInt(2, ven.getId_usuario());
            ps.setDouble(3, ven.getTotal());
            ps.setDouble(4, ven.getEfectivo());
            ps.setDouble(5, ven.getDescuento());
            ps.execute();
            ps.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "No se pudo registrar la venta\nError: "+e);
        }
        return respuesta;
    }
    
    
}
