package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class ConsOperacion extends Conexion{
    
    Connection con = getConexion();
    PreparedStatement ps;
    ResultSet rs;
    
    int respuesta = 0;
    public int registrar(Operacion ope){
        //Script de registro
        String sql = "insert into operacion(id_producto,q,id_tipooperacion,fec_venc) values(?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, ope.getId_producto());
            ps.setInt(2, ope.getQ());
            ps.setInt(3, ope.getId_tipooperacion());
            ps.setString(4, ope.getFecha());
            ps.execute();
            ps.close();
            JOptionPane.showMessageDialog(null, "Producto Registrado");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al Registrar\nError: "+e);
        }
        
        return respuesta;
    }
    
    public int registrarVenta(Operacion ope){
        //Script de registro
        String sql = "insert into operacion(id_producto,q,id_tipooperacion,id_venta) values(?,?,?,?)";
        try {
            ps = con.prepareStatement(sql);
            ps.setInt(1, ope.getId_producto());
            ps.setInt(2, ope.getQ());
            ps.setInt(3, ope.getId_tipooperacion());
            ps.setInt(4, ope.getId_venta());
            ps.execute();
            ps.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al Registrar\nError: "+e);
        }
        
        return respuesta;
    }
    
}
