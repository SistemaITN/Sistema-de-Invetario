package Modelo;

import com.mysql.jdbc.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexion {
    
    //Definicion de variables
    private final String base = "naturesvission";//Nombre Base de datos
    private final String user = "root";//Usuario BD
    private final String password = "";//Passwors BD
    private final String url = "jdbc:mysql://localhost:3306/"+base;//Ubicacion BD
    private Connection con = null;//Definir variable de conexion
    
    public Connection getConexion(){
    
        try{
            Class.forName("com.mysql.jdbc.Driver");//Controlador para conexion
            con = (Connection) DriverManager.getConnection(this.url,this.user,this.password);
            
        }catch(SQLException e){
            System.err.println(e);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
        return con;
    }
    
}
