package Modelo;

import Controlador.CtrlInventario;
import Controlador.CtrlOperacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConsInventario extends Conexion{
    
    public boolean registrar(Venta ven,Operacion ope){
        
        try {
            CtrlInventario ctrlI = new CtrlInventario();
            Connection con = getConexion();
            PreparedStatement ps;
            PreparedStatement ps1;
            String sql = "insert into venta(cod_venta,id_usuario,id_proveedor,total,fecha) values (?,?,?,?,now())";
            ps = con.prepareStatement(sql);
            ps.setString(1, ven.getCod_venta());
            ps.setInt(2, ven.getId_usuario());
            ps.setInt(3, ven.getId_proveedor());
            ps.setDouble(4, ven.getTotal());
            ps.execute();
            String sql1 = "insert into operacion(id_producto,q,fec_venc,id_tipooperacion,id_venta) values (?,?,?,?,?)";
            ps1 = con.prepareStatement(sql1);
            ps1.setInt(1, ope.getId_producto());
            ps1.setInt(2, ope.getQ());
            ps1.setString(3, ope.getFecha());
            ps1.setInt(4, ope.getId_tipooperacion());
            ps1.setDouble(5, ctrlI.idVenta());
            ps1.execute();
            ps1.close();
            return true;
        } catch (SQLException ex) {
            Logger.getLogger(ConsInventario.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }
    
    
}
