package Modelo;

public class Proveedor {

    private int id;
    private String laboratorio;
    private String direccion;
    private String telefono;
    private String pagina;
    private String email;
    private String fecha;
    
    //constructor

    public Proveedor() {
    }

    public Proveedor(int id, String laboratorio, String direccion, String telefono, String pagina, String email, String fecha) {
        this.id = id;
        this.laboratorio = laboratorio;
        this.direccion = direccion;
        this.telefono = telefono;
        this.pagina = pagina;
        this.email = email;
        this.fecha = fecha;
    }
    
    //Getter and Setter

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLaboratorio() {
        return laboratorio;
    }

    public void setLaboratorio(String laboratorio) {
        this.laboratorio = laboratorio;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getPagina() {
        return pagina;
    }

    public void setPagina(String pagina) {
        this.pagina = pagina;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    
    
}
