package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConsProveedor extends Conexion{
    
    //Variables
    Connection con = getConexion();
    //Consultas
    PreparedStatement ps;
    ResultSet rs;
    
    //Funciones
    int respuesta = 0;
    public int registrar(Proveedor pro){
        String sql = "insert into proveedor(laboratorio,direccion,telefono,pagina,correo,fecha) values (?,?,?,?,?,now())";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getLaboratorio());
            ps.setString(2, pro.getDireccion());
            ps.setString(3, pro.getTelefono());
            ps.setString(4, pro.getPagina());
            ps.setString(5, pro.getEmail());
            ps.execute();
            ps.close();
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(ConsProveedor.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        }
    }
    
    public int select(Proveedor pro,int id){
        try {
            String sql = "select * from proveedor where id = ?";
            ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if(rs.next()){
                pro.setLaboratorio(rs.getString("laboratorio"));
                pro.setDireccion(rs.getString("direccion"));
                pro.setTelefono(rs.getString("telefono"));
                pro.setPagina(rs.getString("pagina"));
                pro.setEmail(rs.getString("correo"));
            }
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(ConsProveedor.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        }
        
    }
    
    public int update(Proveedor pro,int id){
        String sql = "update proveedor set laboratorio=?,direccion=?,telefono=?,pagina=?,correo=?,fecha=now() where id = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, pro.getLaboratorio());
            ps.setString(2, pro.getDireccion());
            ps.setString(3, pro.getTelefono());
            ps.setString(4, pro.getPagina());
            ps.setString(5, pro.getEmail());
            ps.setInt(6, id);
            ps.execute();
            ps.close();
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(ConsProveedor.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        }
    }
    
    public int existelab(String lab){
        
        //Script ingreso de datos
        String sql = "select count(id) from proveedor where laboratorio = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, lab);
            rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
            return 1;
        } catch (SQLException ex) {
            Logger.getLogger(ConsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            return 1;
        }
    }
    
    public int obtenerid(String lab){
        
        //Script ingreso de datos
        String sql = "select id from proveedor where laboratorio = ?";
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, lab);
            rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(ConsUsuario.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
    }
    
}
