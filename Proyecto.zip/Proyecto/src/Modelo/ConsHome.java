package Modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConsHome extends Conexion{
    
    public int cantidadProd(){
        try {
            Connection con = getConexion();
            PreparedStatement ps;
            ResultSet rs;
            
            String sql = "select count(id) from producto";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
            rs.close();
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(ConsHome.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
        
    }
    
    public int cantidadVentas(){
        try {
            Connection con = getConexion();
            PreparedStatement ps;
            ResultSet rs;
            
            String sql = "select count(id) from venta where cod_venta like 'F%'";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
            rs.close();
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(ConsHome.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
        
    }
    
    public int cantidadUsu(){
        try {
            Connection con = getConexion();
            PreparedStatement ps;
            ResultSet rs;
            
            String sql = "select count(id) from usuario";
            ps = con.prepareStatement(sql);
            rs = ps.executeQuery();
            if(rs.next()){
                return rs.getInt(1);
            }
            rs.close();
            return 0;
        } catch (SQLException ex) {
            Logger.getLogger(ConsHome.class.getName()).log(Level.SEVERE, null, ex);
            return 0;
        }
        
    }
}
