package Modelo;

public class Operacion {
    
    private int id;
    private int id_producto;
    private int q;
    private String fecha;
    private int id_tipooperacion;
    private int id_venta;
    
    //Constructores

    public Operacion() {
    }

    public Operacion(int id, int id_producto, int q, String fecha, int id_tipooperacion, int id_venta) {
        this.id = id;
        this.id_producto = id_producto;
        this.q = q;
        this.fecha = fecha;
        this.id_tipooperacion = id_tipooperacion;
        this.id_venta = id_venta;
    }
    
    //Get and Set

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_producto() {
        return id_producto;
    }

    public void setId_producto(int id_producto) {
        this.id_producto = id_producto;
    }

    public int getQ() {
        return q;
    }

    public void setQ(int q) {
        this.q = q;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getId_tipooperacion() {
        return id_tipooperacion;
    }

    public void setId_tipooperacion(int id_tipooperacion) {
        this.id_tipooperacion = id_tipooperacion;
    }

    public int getId_venta() {
        return id_venta;
    }

    public void setId_venta(int id_venta) {
        this.id_venta = id_venta;
    }
    
    
    
}
