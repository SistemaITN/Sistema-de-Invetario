package Modelo;

/**
 *
 * @author Marcela
 */
public class Venta {
    
    //Variables
    private int id;
    private String cod_venta;
    private int id_usuario;
    private int id_proveedor;
    private double total;
    private double totalDescuento;
    private double efectivo;
    private double descuento;
    
    //Constructores

    public Venta() {
    }

    public Venta(int id, String cod_venta, int id_usuario, int id_proveedor, double total, double totalDescuento, double efectivo, double descuento) {
        this.id = id;
        this.cod_venta = cod_venta;
        this.id_usuario = id_usuario;
        this.id_proveedor = id_proveedor;
        this.total = total;
        this.totalDescuento = totalDescuento;
        this.efectivo = efectivo;
        this.descuento = descuento;
    }
    
    //Getter and Setter

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCod_venta() {
        return cod_venta;
    }

    public void setCod_venta(String cod_venta) {
        this.cod_venta = cod_venta;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_proveedor() {
        return id_proveedor;
    }

    public void setId_proveedor(int id_proveedor) {
        this.id_proveedor = id_proveedor;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public double getTotalDescuento() {
        return totalDescuento;
    }

    public void setTotalDescuento(double totalDescuento) {
        this.totalDescuento = totalDescuento;
    }

    public double getEfectivo() {
        return efectivo;
    }

    public void setEfectivo(double efectivo) {
        this.efectivo = efectivo;
    }

    public double getDescuento() {
        return descuento;
    }

    public void setDescuento(double descuento) {
        this.descuento = descuento;
    }
    
}
