package Utilidades;

import java.util.List;

public interface ProveedorDeDatosPaginacion<T> {
    
    int getTotalRowCount();
    List <T> getRow(int startIndex,int endIndex);
    
}
